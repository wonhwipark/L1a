# 5.5 RCA 수행 순서 설명서 — L1SW 연동부터 P0~P6까지

작성일: 2026-06-23 KST (v2 — 사용자 관점 재정리)
대상: 사내 PC, `RCA_standalone` 폴더를 연 VSCode + Claude Code

이 문서 한 장이면 **"지금 어느 시점에, 어떤 프롬프트를 넣고, 무엇이 나오는지"**를 안다.
- 개념·이유 → `USAGE_SCENARIO.md`
- 프롬프트 본문(복붙용) → `prompt/CLAUDE_CODE_PROMPTS_e2e_v1.md` 의 P0~P6
- 원인분석 추론법 → `prompt/deepdive/RCA_ANALYSIS_METHODOLOGY.md`

---

## ◆ 먼저 큰 그림 — L1SW 와 5.5 는 어디서 만나는가

```
 [원본 .sdm 로그 704MB]
        │
        │  ◀── L1SW Log Analyzer (사내 기존 스킬). 여기는 5.5 가 아니다.
        │       parse.ps1 이 모듈/시간으로 1차 축소.
        ▼
 [_l1sw.txt  5MB]  ◀════ 5.5 는 "여기서부터" 시작한다. 이 파일이 L1SW와 5.5의 접점.
        │
        │  ◀── 5.5 RCA (P3~P6). 원인분석 + 지식 누적.
        ▼
 [case YAML + keywords.yaml 성장]
```

핵심 한 줄: **L1SW 는 로그를 줄이는 도구, 5.5 는 줄인 로그에서 원인을 캐고 쌓는 도구.**
둘의 만나는 지점이 `_l1sw.txt` 파일 하나다.

---

## ◆ 전체 타임라인 — 언제 무엇을

표 한 장으로 "시점 → 프롬프트 → 결과물"을 본다. P0~P6 은 프롬프트 파일의 블록 이름이다.

| 시점 | 단계 | 넣는 프롬프트 | 한마디로 무슨 동작 | 나오는 결과물 | 사람이 하는 일 |
|---|---|---|---|---|---|
| **최초 1회**<br>(환경 셋업) | A | (프롬프트 없음) | L1SW 스킬 경로 확인 | parse.ps1·manifest 경로 메모 | 경로 확인 |
| | B | **P0** | 환경 자가 진단 | 가능/불가 진단표 | 표 읽기 |
| | C | **P1** | `_l1sw.txt` 형식 역설계 | 형식 정리 문서 | cptime 포맷 1회 확인 |
| | D | **P2** | manifest fragment 후보 생성 | issue_type별 JSON + 근거표 | 구조 일치 확인 |
| **로그마다**<br>(반복) | E | (프롬프트 없음) | L1SW 실행 | `_l1sw.txt` (축소본) | parse.ps1 실행 |
| | F | **P3** | signal 추출 | `signals/..._signal.txt` | signature 횟수 훑기 |
| | G | **P4** | 원인분석 7단계 + case 생성 | case YAML + 인과사슬 | 변경 요약 확인 |
| | H | **P5** | 자가점검 → 승인 | `status: reviewed` case | **"승인"** 입력 |
| | I | **P6** | keywords 승격 | confirmed 갱신 + 버전↑ | before/after 확인 |

> 사람의 실질 입력은 딱 둘: **E(L1SW 실행)** 와 **H("승인")**. 나머지는 결과 확인뿐.

이제 각 단계를 카드로 풀어 본다.

---

# 【최초 1회 — 환경 셋업 (A~D)】

환경이 바뀌지 않는 한 한 번만 한다. 이게 끝나면 로그마다 E~I 만 반복한다.

---

## STEP A — L1SW 스킬 연동 확인  〔프롬프트 없음〕

**언제**: 가장 먼저. P0 돌리기 전.
**왜**: 5.5 의 입력은 L1SW 가 만든 `_l1sw.txt` 다. 그 도구가 이 PC에서 도는지부터 확인한다.

**무슨 동작 (사람이 직접)**
PowerShell에서 스킬과 manifest 가 있는지 본다:
```powershell
Test-Path "C:\Users\whpark\.claude\skills\l1sw-log-analyzer\scripts\parse.ps1"
Get-ChildItem "C:\Users\whpark\.claude\skills\l1sw-log-analyzer\manifest\"
```
그리고 **VSCode/Claude Code 에서 `RCA_standalone` 폴더 자체를 연다**(상위 폴더 열면
프롬프트의 `@상대경로` 가 깨진다).

**결과물**: (파일 없음) parse.ps1 경로 + manifest 디렉토리 경로를 손에 쥔 상태.
**사람이 하는 일**: 경로 2개 확인. 끝.
**다음 신호**: `True` 와 manifest JSON 목록이 보이면 STEP B 로.

> (선택) Jira/Confluence MCP 를 쓸 거면 `prompt/MCP_PERSIST_SETUP_PROMPTS.md` 로 먼저
> `.mcp.json` 을 깔아둔다. RCA 분석에는 필수 아님.

---

## STEP B — P0 환경 자가 진단  〔프롬프트: P0〕

**언제**: STEP A 직후.
**왜**: "지금 바로 시작 가능한가, 뭐가 빠졌나"를 Claude Code 가 스스로 점검하게.

**넣는 것**: `CLAUDE_CODE_PROMPTS_e2e_v1.md` 의 **P0** 블록을 통째로 복사 → Claude Code 에 붙여넣기.

**무슨 동작**: Claude Code 가 `.sdm`/`_l1sw.txt` 존재, L1SW 경로, PowerShell 가능 여부,
기존 case 수, signals 폴더 상태를 스스로 조사한다.

**결과물 (화면에 표)**:
```
항목            | 상태       | 다음 조치
.sdm 파일       | 있음(3개)  | -
_l1sw.txt       | 없음       | STEP E 에서 생성
L1SW parse.ps1  | 발견       | -
PowerShell      | 가능       | -
기존 case 수    | 1 (예시)   | -
→ 지금 P1부터 시작 가능한가? : yes
```
**사람이 하는 일**: 표의 "다음 조치" 열과 맨 아래 yes/no 읽기.
**막히면**: no 가 나오고 L1SW 를 못 찾으면 → STEP A 에서 메모한 경로를 알려준다.
**다음 신호**: "yes" 또는 빠진 항목이 채워지면 STEP C 로.

---

## STEP C — P1 `_l1sw.txt` 형식 역설계  〔프롬프트: P1〕

**언제**: P0 가 yes 를 준 뒤. (단, `_l1sw.txt` 가 하나라도 있어야 형식을 뜬다 → 없으면 STEP E 먼저 1회)
**왜**: cptime·module 표기 형식을 알아야 뒤의 manifest(P2)·cptime_range 추출(P4)이 정확해진다.

**넣는 것**: **P1** 블록.

**무슨 동작**: 실제 `_l1sw.txt` 샘플을 떠서 줄 구조를 역설계한다 —
cptime 이 어떻게 찍히는지(`[00123.456]` 같은), module 이름이 어디 오는지, 한 줄에 뭐가 들었는지.

**결과물 (파일)**: `prompt/deepdive/L1SW_OUTPUT_FORMAT_PROBED_<날짜>_KST.md`
— "cptime 포맷 = …, module 위치 = …, 라인번호 없음" 같은 형식 명세.

**사람이 하는 일**: cptime 포맷 한 줄이 실제와 맞는지 눈으로 1회 확인.
**다음 신호**: 형식 문서가 생기면 STEP D 로.

---

## STEP D — P2 manifest fragment 후보 생성  〔프롬프트: P2〕

**언제**: 형식(P1)을 안 뒤.
**왜**: L1SW 의 1차 필터를 "issue_type 을 아는" 필터로 보강하기 위한 키워드 묶음을 자동으로 만든다.

**넣는 것**: **P2** 블록.

**무슨 동작**: `keywords.yaml` 에서 `use_for.l1sw_manifest_fragment: true` 인 signature 만
issue_type별로 뽑아 fragment JSON 후보를 만든다. generic(RACH/SCG/RLC/HARQ)은 제외.
사람이 키워드를 손으로 고르지 않는다.

**결과물 (파일)**:
- `rca_kg/manifest_fragments/rca_rach.json` 등 issue_type별 JSON 후보
- review_log 에 "포함/제외 근거 + 기존 L1SW fragment 구조와 일치하는지" 표

**사람이 하는 일**: 구조 일치 표만 확인. (원하면 이 JSON 을 사내 L1SW manifest 에 반영 — 선택)
**다음 신호**: 여기까지가 셋업 끝. 이제 분석할 로그가 생길 때마다 STEP E 부터 반복.

---

# 【로그마다 반복 (E~I)】

새 `.sdm` 로그가 나올 때마다 이 5단계만 돈다.

---

## STEP E — L1SW 실행  〔프롬프트 없음 / 사람이 실행〕

**언제**: 분석할 `.sdm` 이 생길 때마다 맨 처음.
**왜**: 704MB 원본을 5.5 가 다룰 수 있는 5MB `_l1sw.txt` 로 줄인다.

**무슨 동작 (사람이 직접)**:
```powershell
cd "C:\Users\whpark\.claude\skills\l1sw-log-analyzer\scripts"
# parse.ps1 의 정확한 입력 파라미터명은 환경마다 다를 수 있다.
# P0/P1 이 조사해 알려준 실제 호출 형태를 그대로 쓴다.
.\parse.ps1 <P0/P1이 알려준 입력 파라미터> "D:\logs\dump001.sdm"
#   옵션: -Modules <부분집합>  -TimeFrom/-TimeTo <시간창>
```

**결과물 (파일)**: `_l1sw.txt` (예: 704MB → 5MB).
— stdout 마지막 줄에 경로가 찍힌다. **그 경로를 복사**해 둔다(다음 단계 입력).
**사람이 하는 일**: parse.ps1 실행, 출력 경로 확보.

> 주의: 이 `_l1sw.txt` 는 **지우지 않는다**. case 는 로그 본문을 복사하지 않고 이 파일 경로 +
> cptime 만 가리킨다(필요할 때 본문을 되읽기 위해). / crash·dump 분석은 L1SW 담당이고
> 5.5 는 crash case 를 만들지 않는다.

---

## STEP F — P3 signal 생성  〔프롬프트: P3〕

**언제**: `_l1sw.txt` 경로를 손에 쥔 직후.
**왜**: `_l1sw.txt` 에서 이번 issue_type 에 관련된 줄만 더 좁혀 분석 입력(signal)을 만든다.

**넣는 것**: **P3** 블록. 상단 자리표시자 2개를 채운다:
- 대상 issue_type: `rach_failure | scg_failure | tx_abnormal | l2_max_retransmission` 중 하나
- 입력 `_l1sw.txt` 경로: STEP E 에서 복사한 경로

**무슨 동작**: 환경에 맞는 경로를 Claude Code 가 알아서 고른다 — 파일이 작으면 그대로 복사,
크면 `keywords.yaml` 기반 pre-filter(또는 `scripts/<issue_type>_prefilter.ps1`)로 줄인다.
(스크립트 키워드가 keywords.yaml 과 다르면 차이를 먼저 보고만 하고 자동 수정 안 함.)

**결과물 (파일)**: `rca_kg/signals/<날짜>_<issue_type>_<source>_signal.txt`
+ 화면에 signature ID별 등장 횟수.

**사람이 하는 일**: 등장 횟수를 훑는다.
**막히면**: **횟수가 전부 0 이면 issue_type 을 잘못 고른 것** → 횟수가 잡히는 issue_type 으로 P3 재실행.
**다음 신호**: signal 파일이 생기면 STEP G 로.

---

## STEP G — P4 원인분석 7단계 + case 생성  〔프롬프트: P4〕 ★핵심

**언제**: signal 이 만들어진 뒤.
**왜**: 이 단계가 진짜 "원인 캐기". 방법론 7단계로 root_cause 를 도출하고 case YAML 로 굳힌다.

**넣는 것**: **P4** 블록. issue_type 과 P3 signal 경로를 채운다.

**무슨 동작 — 2부로 진행**:
- **PART A (원인분석)**: `RCA_ANALYSIS_METHODOLOGY.md` 7단계 수행 →
  ① 증상 anchor 고정 → ② 시간창 → ③ 정상경로와 대조해 "최초 이탈 지점" 특정 →
  ④ 가설 2~4개 → ⑤ 가설 가르는 단서만 grep → ⑥ 단말 vs 환경 분리 → ⑦ 인과사슬 + confidence.
  (각 단계 결론과 근거 cptime 이 화면에 표시된다.)
- **PART B (case 작성)**: PART A 결과를 schema v2 필드로 매핑.
  signature 는 keywords.yaml **ID 표기**, root_cause.summary 는 **인과사슬 문장**(증상 나열 금지),
  위치는 **cptime_range 만**.

**결과물 (파일 + 화면)**:
- `rca_kg/cases/<...>.yaml` (신규) **또는** 기존 case 의 `occurrence_count++` (같은 fingerprint 재발 시)
- 환경/RF 원인이면 → `rca_kg/cases/unresolved/<...>PENDING.yaml` + handoff 블록
- 화면: 변경 요약표 + **인과사슬 1줄** + confidence(근거) + 재발/신규/이관 판정

**사람이 하는 일**: 변경 요약표와 인과사슬 1줄을 읽는다. (승인은 다음 단계)
**다음 신호**: case 가 만들어지면 STEP H 로.

---

## STEP H — P5 자가점검 → 승인  〔프롬프트: P5〕

**언제**: case 가 생성·갱신된 뒤.
**왜**: 사람이 손대는 거의 유일한 단계. 그마저도 Claude Code 가 체크리스트를 채워주고 사람은 OK/수정만.

**넣는 것**: **P5** 블록. P4 가 만든 case 경로를 채운다.

**무슨 동작**: case 를 항목별로 자가점검(OK/의심/위반) — 특히
ID 표기 위반 / 인과사슬 vs 증상나열 / confidence 정합 / 환경원인을 low 로 들고 있지 않은지.
통과하면 적용할 'review 승인 패치'를 미리 보여준다(아직 적용 X).

**결과물**:
- 화면: 점검표 + 승인 패치 미리보기
- 승인 후: case 에 `status: reviewed`, `review.reviewer: whpark` 적용 + `index.md` 갱신

**사람이 하는 일**: 점검표 보고 문제없으면 **`승인`** 한 단어 입력.
이상한 필드가 있으면 그 필드만 지적 → 그 부분만 고치고 점검표 다시 보여줌.
**다음 신호**: reviewed 되면 STEP I 로.

---

## STEP I — P6 keywords.yaml 승격  〔프롬프트: P6〕

**언제**: case 가 승인된 뒤.
**왜**: 이번 실로그로 검증된 signature 를 confirmed 로 올려 **다음 분석 정확도를 높인다**(학습 루프).

**넣는 것**: **P6** 블록. P4 가 알려준 "실로그로 확인된 candidate signature ID 목록"을 채운다.

**무슨 동작**: 확인된 candidate signature 를 `keywords.yaml` 에서 `candidate → confirmed` 로
승격하고 note 에 근거(case_id, cptime)를 남긴다. 버전 0.1→0.2 로 올린다.
(generic 정책 유지 — RACH/SCG/RLC/HARQ 는 confirmed 여도 fingerprint 엔 안 씀.)

**결과물 (파일 + 화면)**: 갱신된 `keywords.yaml` + before/after 표.
**사람이 하는 일**: before/after 표 확인. 승격이 과하면 해당 ID 만 되돌리라고 지시.
**의미**: 이 단계가 **닫힌 학습 루프**. 분석할수록 SSOT 가 검증과 함께 자란다.

---

# 【반복 구조 & 분기】

```
최초 1회 :  A(L1SW 연동) → B(P0) → C(P1) → D(P2)
로그마다 :  E(L1SW 실행) → F(P3) → G(P4) → H(P5) → I(P6)
              ├ 같은 fingerprint 재발 → G 에서 occurrence_count++ 로 끝(case 안 늘어남)
              └ 담당영역 밖(RF/환경) → G 에서 unresolved 분기 → 이관 → 담당자가 채워 통합
```

## 막혔을 때 빠른 분기표

| 증상 | 어느 단계 | 원인 | 조치 |
|---|---|---|---|
| P0 가 L1SW 못 찾음 | B | 스킬 경로 다름 | A-1 경로를 P0 에 알려줌 |
| P1 이 멈추고 명령만 줌 | C | `_l1sw.txt` 없음 | E 를 먼저 1회 실행 후 C 로 |
| P3 signature 횟수 전부 0 | F | issue_type 오선택 | 횟수 잡히는 issue_type 으로 P3 재실행 |
| P4 confidence 애매 | G | 최초 이탈 위 단서 부족 | `analyzed`+`low` 유지(담당영역 안) |
| 원인이 RF/환경 | G | 담당영역 밖 | `unresolved`+handoff (low 로 우기지 말 것) |
| 모바일/외부 PC | E,F | L1SW·PowerShell 불가 | E~F 는 사내 PC 전용 |

---

## 한 줄 요약

```
[셋업 1회] L1SW 연동 확인 → P0 진단 → P1 형식 → P2 fragment
[로그마다] L1SW 실행 → P3 signal → P4 원인분석+case → P5 "승인" → P6 승격
사람은 'L1SW 실행' 과 '승인' 두 번만. 분석 품질은 METHODOLOGY 7단계가 책임진다.
접점은 _l1sw.txt 파일 하나. case 는 본문을 복사하지 않고 그 경로+cptime 만 가리킨다.
```
