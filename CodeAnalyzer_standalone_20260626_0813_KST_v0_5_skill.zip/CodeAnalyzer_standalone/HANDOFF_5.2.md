# HANDOFF — CodeAnalyzer Standalone 세션 인계

마지막 갱신: 2026-06-26 01:16 KST  
새 세션은 이 파일을 먼저 읽어 상태를 복원한 뒤, `NEXT_STEP_5.2.md`로 다음 행동을 잡는다.

---

## 1. 이 패키지가 왜 생겼나

L1a Master v0.40 §5.2 Code Analyzer를 RCA_standalone처럼 별도 트랙으로 추출한 것이다.

목적:

```text
- 특정 L1 블록의 동작을 HLD 없이 복원
- 특정 API 기준 full call flow + MSC 생성
- 대형 코드에서 staged 분석으로 토큰 사용량 제어
- RCA 5.5에서 root cause code reference로 재사용 가능한 HLD성 md 축적
```

---

## 2. v0.2/v0.3에서 반드시 기억할 결정

### Decision 0 (v0.3) — 산출물 루트 폴더를 output/으로 이동

v0.3에서 산출물 루트 폴더명을 `artifacts/` → `output/`으로 바꿨다. canonical path는 이제 아래와 같다.

```text
output/5.2/<slug>/
```

산출물 구조의 권위는 스킬 `code-analyzer`가 가지며, layout 단일 문서는 `output/5.2/_example_slug/README.md`다. v0.2로 만든 산출물은 폴더명만 1회 옮기면 그대로 이어쓸 수 있다.

```powershell
if (Test-Path .\artifacts\5.2) { Move-Item .\artifacts\5.2\* .\output\5.2\ -Force }
```

### Decision 1 — 산출물(output) 경로 단일화

모든 산출물 경로는 아래 하나로 고정한다.

```text
output/5.2/<slug>/
```

이 경로는 Track B, Track A Phase 0, resume, NEXT_STEP, analysis_progress, schema 문서에서 모두 동일하게 사용한다.

폐기 경로:

```text
%USERPROFILE%\artifacts\code_analyzer\<slug>\
artifacts/5.2/<slug>/                            # v0.2 경로. v0.3에서 output/5.2/로 이동
artifacts\code_analyzer\<slug>\
```

이 결정은 v0.2의 핵심이다. 경로가 이원화되면 Track B가 쓴 `structure_*.json`을 Track A가 못 찾고, resume도 깨진다.

### Decision 2 — extraction_mode enum 통일

추출 방식은 아래 enum만 사용한다.

```text
extraction_mode: git | bash | powershell | internal_search | mixed
```

다음 표현은 쓰지 않는다.

```text
shell_mode
git_bash
unknown
fallback_mode
```

### Decision 3 — 진행줄 token cursor 통일

진행줄은 산문이 아니라 토큰형으로 쓴다.

```text
[진행: PHASE0_DONE → 다음: PHASE1_PROCEDURE_DISCOVERY]
```

이 토큰을 resume key로 사용할 수 있어야 한다.

### Decision 4 — 전역 누적 call edge 본문 제거

`analysis_progress.md`는 매번 전체를 읽는 resume 입력이다. 따라서 procedure가 늘어날수록 커지는 전역 누적 call edge 본문 블록을 두지 않는다.

```text
금지: 전역 call edge 누적 본문 본문 블록
허용: procedure별 local_call_edges
허용: 전역 EDGE_IDS_DONE 같은 id 요약
```

### Decision 5 — procedure_runtime_index 도입

Phase 1이 structure json을 한 번 읽어 procedure별 작은 실행 인덱스를 만든다. Phase 2..N은 이 인덱스 slice만 읽는다.

```text
Phase 1: structure json → procedure_runtime_index 생성
Phase 2..N: procedure_runtime_index[procedure_slug]만 사용
fallback: index_status가 INDEX_INCOMPLETE일 때만 structure targeted read
```

### Decision 6 — MSC 분리 .puml 통일

MSC는 HLD .md 내부에 inline PlantUML 코드블록으로 넣지 않는다.

```text
output/5.2/<slug>/msc_<procedure_slug>_<YYYYMMDD_HHMM_KST>.puml
```

HLD .md에는 `msc_ref` 링크와 동작 설명만 둔다.

---

## 3. v0.2에서 보강된 안정화 항목

1. Windows/PowerShell fallback 추가.
2. CNF handler 단일 가정 제거. `ipc_cnf_handlers[]` 후보 배열 사용.
3. structure.json 크기 제한 추가.
4. Track B grep 결과 상한 추가.
5. 실행용 copy prompt 추가.
6. schema 문서 추가.
7. slug 생성 규칙 명문화.
8. runtime 반복 read 누수 차단.
9. structure 자동 탐색 우선순위 고정: focused 우선, full은 300KB 이하만 자동 사용.
10. reference prompt 런타임 read 차단 문구 추가.

---

## 4. 산출물 단위 결정

```text
1 블록 = HLD성 .md 1개
1 procedure = MSC .puml 1개
API 기준 모드 = 블록 기준 모드의 부분집합
```

모드 A:

```text
블록명 입력 → 수신 handler/API 열거 → procedure 후보 목록 → 범위 선택 → HLD성 md
```

모드 B:

```text
API명 입력 → 단일 procedure → 블록 HLD 합류 또는 독립 md 선택
```

---

## 5. 열린 항목

1. 실제 사내 L1 코드 1개 블록 대상 E2E 검증 필요.
2. RCA 5.5 `root_cause.code_ref` 연결 계약은 첫 HLD 산출물 이후 확정.
3. Stage 분할 임계값은 실데이터로 조정.

---

## 6. 다음 세션 권장 시작점

```text
1. NEXT_STEP_5.2.md 읽기
2. 세션 시작 시 prompt/copy_session_bootstrap.md 1회 붙여넣기 (공통 규칙 적용, 토큰 절감)
3. 작은 블록이면 prompt/copy_phase0.md 실행
4. 대형 코드면 prompt/copy_track_b.md 실행 후 prompt/copy_phase0.md 실행
5. Phase 1은 prompt/copy_phase1.md 실행
6. procedure 진행은 prompt/copy_next_procedure.md 실행
7. analysis_progress.md가 있으면 prompt/copy_resume.md로 이어가기
```
