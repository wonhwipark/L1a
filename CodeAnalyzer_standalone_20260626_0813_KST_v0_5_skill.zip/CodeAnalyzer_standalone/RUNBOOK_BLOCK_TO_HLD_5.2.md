# RUNBOOK — Block/API 입력에서 HLD성 .md까지

이 문서는 막혔을 때 보는 분기표다. 정상 흐름은 `START_HERE_5.2.md`를 따른다.

---

## A. 시작 분기 — 무엇을 갖고 있나

| 상황 | 가는 길 |
|---|---|
| 블록 이름만 안다 | 모드 A. Track A Phase 0 → Phase 1 procedure 목록 |
| 특정 API/메시지를 콕 집어 보고 싶다 | 모드 B. Track A Phase 0 + API명 |
| 코드가 20파일 이상 또는 5천 LOC 이상 | Track B 선행 권장 |
| 코드루트가 수백~수천 파일 | Track B 선행 후 Track A |
| 어느 블록인지도 모르겠다 | Track B로 modules/ipc_req_sites 후보 확인 |

---

## B. 경로 문제

| 증상 | 원인 | 조치 |
|---|---|---|
| Track B는 성공했는데 Phase 0이 structure를 못 찾음 | 경로 이원화 | `output/5.2/<slug>/structure_*.json`에 있는지 확인 |
| `analysis_progress.md`가 두 위치에 생김 | 옛 경로 사용 | `%USERPROFILE%\artifacts\code_analyzer` 경로 사용 중지 |
| resume이 이전 상태를 못 읽음 | slug 불일치 또는 경로 불일치 | slug와 canonical path 재확인 |

canonical path:

```text
output/5.2/<slug>/
```

---

## C. structure 자동 탐색 문제

| 증상 | 원인 | 조치 |
|---|---|---|
| Phase 0이 1MB짜리 full structure를 열려고 함 | 자동 탐색 우선순위 미준수 | focused 우선, full은 300KB 이하만 자동 사용하도록 수정 |
| `structure_<ts>_full.json`만 있고 300KB 초과 | 자동 인계 대상 아님 | Track B를 다시 실행해 `structure_<ts>_focused.json` 생성 |
| `meta.root`가 입력 코드루트와 다름 | 다른 root의 캐시를 집음 | 새 focused structure 생성 |
| `meta.slug`가 현재 slug와 다름 | slug 불일치 | slug 고정 후 새 structure 생성 |

자동 탐색 우선순위:

```text
1. structure_*_focused.json 최신 파일
2. structure_*.json 중 300KB 이하인 최신 파일
3. 300KB 초과 full structure는 명시 지정 시에만 사용
```

---

## D. Phase 0에서 막힘

| 증상 | 조치 |
|---|---|
| structure.json 자동 탐색 실패 | canonical path에 focused structure가 있는지 확인. 없으면 Phase 0 focused extraction 허용 |
| `meta.root`가 입력 코드루트와 다름 | 다른 slug 또는 다른 root의 캐시를 집은 것. 새 structure 생성 |
| structure가 1MB 초과 | focused structure 생성. 관련 subgraph만 남김 |
| 스킬 Test-Path False | 사내 스킬 설치부터 진행 |

---

## E. Track B에서 막힘

| 증상 | 조치 |
|---|---|
| `find`, `grep`, `xargs` 실패 | PowerShell fallback 사용 |
| Git Bash 없음 | `extraction_mode: powershell`로 진행 |
| ctags 없음 | 함수 추출은 grep/Select-String 폴백. `extraction_mode`는 실제 혼합이면 `mixed` |
| grep 결과 과다 | 패턴별 최대 200줄 1차 수집, block/API 후보 파일로 축소 |
| full structure가 계속 커짐 | `_focused.json` 파일을 생성하고 full은 명시 지정용으로만 보관 |

fallback 순서:

```text
1. git
2. bash
3. powershell
4. internal_search
5. mixed
```

---

## F. Phase 1에서 막힘

| 증상 | 조치 |
|---|---|
| procedure 목록이 비었다 | 블록명을 handler 함수/파일명에 가깝게 다시 지정 또는 API 모드로 진입 |
| procedure가 너무 많다 | 범위 확인에서 일부만 선택 |
| 다른 블록 procedure가 섞임 | structure call_edges와 file ownership 재확인. 모호하면 [RN] |
| procedure_runtime_index가 생성되지 않음 | Phase 1 실패로 간주. `copy_phase1.md` 기준으로 다시 생성 |
| index_status가 전부 INDEX_INCOMPLETE | structure가 너무 빈약함. Track B focused extraction 보강 |

---

## G. Phase 2..N에서 막힘

| 증상 | 조치 |
|---|---|
| Phase 2가 매번 structure_focused.json 전체를 읽음 | 잘못된 흐름. procedure_runtime_index의 해당 slice만 읽도록 중단 후 재지시 |
| CNF 후보가 여러 개 | `ipc_cnf_handlers[]` 후보로 유지하고 procedure별 Phase에서 확정 |
| CNF side가 계속 pending | CNF 후보 파일을 targeted 1회 read. 확정 못하면 `[RN] CNF side pending` |
| macro 안에 IPC가 숨음 | macro 정의 파일만 targeted read. 그래도 불명확하면 `[RN] macro-wrapped` |
| MSC가 너무 커짐 | procedure 분할 재검토. 한 MSC = 한 procedure 원칙 유지 |
| HLD .md에 PlantUML inline이 들어감 | 잘못된 흐름. 별도 `.puml` 저장 + HLD에는 `msc_ref` 링크로 수정 |

---

## H. analysis_progress.md 비대화 문제

| 증상 | 원인 | 조치 |
|---|---|---|
| procedure가 늘수록 progress가 급격히 커짐 | 전역 call edge 본문 누적 | 전역 누적 블록 제거, procedure별 local_call_edges로 이동 |
| resume 시 이전 procedure edge를 계속 다시 읽음 | 전역 누적 블록 사용 | 전역에는 id 요약만 남김 |
| Phase F가 HLD md 전체 MSC를 다시 처리함 | inline PlantUML 사용 | `.puml` 분리 후 HLD에는 링크만 유지 |

금지:

```text
## 전역 call edge 누적 본문
- <from> -> <to> ...
```

허용:

```text
procedure별 결과 요약.local_call_edges
Global Edge ID Summary (ids only)
```

---

## I. 산출물 / 머지

| 상황 | 조치 |
|---|---|
| 같은 procedure 재분석 | overwrite 금지. 새 timestamp md/puml로 저장 후 머지 필요 표시 |
| API 모드 결과를 블록 HLD에 합칠지 애매 | Phase 1에서 사용자가 1회 선택 |
| 블록 HLD 완료 후 다음 블록 | `[진행: BLOCK_HLD_DONE:<slug> → 다음: WAIT_NEW_BLOCK]` 후 새 Phase 0 |

---

## J. 진행줄 표준

사용 가능한 진행줄 예:

```text
[진행: INIT → 다음: TRACK_A_PHASE0]
[진행: TRACKB_DONE → 다음: TRACK_A_PHASE0]
[진행: PHASE0_DONE → 다음: PHASE1_PROCEDURE_DISCOVERY]
[진행: PHASE1_DONE → 다음: PROC_NEXT:<procedure_slug>]
[진행: PROC_DONE:<procedure_slug> → 다음: PROC_NEXT:<next_procedure_slug>]
[진행: PROC_DONE:<procedure_slug> → 다음: PHASEF_FINALIZE]
[진행: BLOCK_HLD_DONE:<slug> → 다음: WAIT_NEW_BLOCK]
```
