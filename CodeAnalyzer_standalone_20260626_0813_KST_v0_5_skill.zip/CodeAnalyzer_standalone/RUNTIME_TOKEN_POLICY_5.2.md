# RUNTIME_TOKEN_POLICY — CodeAnalyzer 5.2

작성일: 2026-06-26 01:16 KST

이 문서는 v0.2에서 확정한 런타임 토큰 절감 정책만 별도로 정리한다.

---

## 1. reference prompt 반복 read 금지

런타임 실행에는 아래 reference prompt를 다시 읽지 않는다.

```text
prompt/5.2_track_a_prompt.md
prompt/5.2_track_b_prompt.md
```

실제 실행에는 아래 copy prompt만 사용한다.

```text
prompt/copy_session_bootstrap.md   # 세션 시작 시 1회
prompt/copy_track_b.md
prompt/copy_phase0.md
prompt/copy_phase1.md
prompt/copy_next_procedure.md
prompt/copy_resume.md
prompt/copy_phase_f.md
```

`copy_session_bootstrap.md`는 세션당 1회만 붙여넣어 공통 고정 규칙(경로/enum/진행줄/런타임 read 정책)을 한 번에 적용한다. 이후 단계 prompt에서 같은 규칙을 매번 길게 재기술하지 않아도 되므로 입력 토큰이 줄어든다.

---

## 2. analysis_progress.md 비대화 방지

`analysis_progress.md`는 resume 시 매번 읽는 파일이므로 무한히 커지는 누적 로그로 사용하지 않는다.

금지:

```text
전역 call edge 누적 본문 블록
```

허용:

```text
procedure별 결과 요약.local_call_edges
Global Edge ID Summary (ids only)
```

---

## 3. procedure_runtime_index 우선

Phase 1은 structure json을 읽고 작은 실행 인덱스를 만든다.

```text
procedure_runtime_index
```

Phase 2..N은 해당 procedure slice만 읽는다.

```text
PROC_NEXT:<procedure_slug>
  → procedure_runtime_index[procedure_slug]
  → related_files / req_site_ids / cnf_handler_candidate_ids / call_edge_ids
```

---

## 4. structure json 반복 read 금지

`structure_focused.json`은 Phase 1 인덱스 생성 source다. Phase 2..N의 반복 입력이 아니다.

```text
index_status: READY              → structure json 재read 금지
index_status: INDEX_INCOMPLETE   → 필요한 범위만 targeted fallback read
```

---

## 5. structure 자동 탐색 우선순위

```text
1. output/5.2/<slug>/structure_*_focused.json 최신 파일
2. output/5.2/<slug>/structure_*.json 중 300KB 이하인 최신 파일
3. 300KB 초과 full structure는 사용자가 명시한 경우에만 사용
```

---

## 6. MSC 분리 저장

MSC는 HLD md 안에 넣지 않고 별도 `.puml` 파일로 저장한다.

```text
output/5.2/<slug>/msc_<procedure_slug>_<YYYYMMDD_HHMM_KST>.puml
```

HLD md에는 아래만 남긴다.

```text
msc_ref: output/5.2/<slug>/msc_<procedure_slug>_<YYYYMMDD_HHMM_KST>.puml
procedure 동작 설명
call flow 요약
[RN] 목록
```
