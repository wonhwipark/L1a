# VERSION — CodeAnalyzer Standalone

- **Package:** CodeAnalyzer_standalone
- **Version:** v0.5
- **Updated:** 2026-06-26 08:13 KST
- **Origin:** L1a 5.2 Code Analyzer (Master v0.40 §5.2) 에서 별도 트랙으로 추출
- **Model reference:** RCA_standalone v0.14 (START_HERE / NEXT_STEP / 경량 stateful 패턴)

---

## 0-0. v0.5 Headline Goal — code-analyzer 스킬화

copy prompt 묶음을 실제 `code-analyzer` 스킬로 승격했다. 사람이 대본을 수동으로 붙여넣던 방식에서, 스킬이 자동 진행하는 방식으로 바뀌었다.

```text
1. skills/code-analyzer/ 신규 — SKILL.md + references/ 7개. /code-analyzer로 즉시 호출.
   (기존 staged-code-analyzer를 code-analyzer로 개명·승격. 작은 API~대형 모듈 전부 커버.)
2. 세션 부트스트랩 자동화 — copy_session_bootstrap 규칙을 SKILL.md에 내장. 붙여넣기 불필요.
3. Track A/B 자동 판별 — 메타 스캔(파일 수·LOC, 0토큰)으로 자동 결정. 경계값만 사람 확인.
4. 블록/API 전환 + 복귀 — 분석 중 다른 블록 끼어들기 후 이전 cursor로 복귀(block_stack LIFO).
```

레거시 copy prompt는 스킬 미설치 환경을 위해 그대로 유지한다(하위 호환).

---

## 0. v0.4 Headline Goal — 사용자 편의

v0.4는 동작/토큰 정책은 v0.3 그대로 두고, **사람이 손으로 채우는 일을 없애는** 편의 릴리스다.

```text
1. slug 자동 승계: Phase 0이 NEXT_STEP.current_slug에 기록 → 이후 단계는 slug 재입력 불필요
2. 타임스탬프/구조파일명 자동화: 사람이 <YYYYMMDD_HHMM_KST>나 structure 파일명을 적지 않음
   → copy prompt가 최신 *_focused.json을 자동 선택
3. 다음 파일 안내: 모든 진행줄 다음 줄에 "▶ 다음 붙여넣기: prompt/<파일>.md"
4. 문서 지도: START_HERE 상단에 "평소엔 이 파일 하나면 된다" 3줄 지도
```

효과: 사람이 채우던 placeholder 70여 개가 사실상 첫 입력(코드루트 + 블록명) 2개로 줄어든다.

---

## 0-1. v0.3 핵심 변경 — 산출물 경로를 output/으로 이동 (유지)

v0.3은 v0.2의 모든 규칙을 유지하면서, 산출물 경로 명명과 사용 편의/토큰 절감만 보강한 점진 릴리스다.

```text
1. 산출물 경로를 artifacts/ → output/ 으로 이동 (output/5.2/<slug>/)
2. 산출물 layout/template의 권위를 스킬(code-analyzer) 쪽으로 단일화
3. 스킬 설치 점검을 ALL_OK/MISSING 단일 체크로 단순화 (BEL 바이트 깨짐 수정)
4. copy prompt 입력 토큰 추가 절감 (공통 규칙 1회 참조화)
```

v0.2 → v0.3 마이그레이션은 폴더명 한 번만 바꾸면 된다. 내용 계약은 동일하다.

```powershell
if (Test-Path .\artifacts\5.2) { Move-Item .\artifacts\5.2\* .\output\5.2\ -Force }
```

---

## 1. v0.2 Headline Goal (유지)

v0.2의 헤드라인 목표는 다음 3개다.

```text
1. slug/cache/structure 경로 고정
2. Track B 추출 방식 enum 통일
3. resume 가능한 토큰형 진행줄 통일
```

모든 산출물 경로는 아래 canonical 상대경로로 고정한다.

```text
output/5.2/<slug>/
```

아래 경로는 더 이상 사용하지 않는다.

```text
%USERPROFILE%\artifacts\code_analyzer\<slug>\   # 폐기
artifacts\code_analyzer\<slug>\                  # 폐기
artifacts/5.2/<slug>/                           # v0.2 경로. v0.3에서 output/5.2/로 이동
output/5_2/<slug>/                              # 폐기
```

이 통일은 Track B가 생성한 `structure_*.json`을 Track A Phase 0이 자동으로 찾고, `analysis_progress.md` 기반 resume이 깨지지 않게 하기 위한 필수 변경이다.

---

## 2. v0.2 런타임 토큰 절감 보강

copy prompt 분리로 reference prompt 반복 입력은 줄였다. 추가로 v0.2는 런타임 반복 read 누수를 막기 위해 아래 정책을 흡수했다.

```text
1. analysis_progress.md에서 전역 confirmed call edges 누적 본문 블록 제거
2. procedure별 edge 본문은 각 procedure 결과 섹션 내부에만 기록
3. 전역에는 필요 시 EDGE001 같은 id만 요약
4. Phase 1이 procedure_runtime_index를 생성
5. Phase 2..N은 procedure_runtime_index의 해당 slice만 읽음
6. structure_focused.json은 매 procedure마다 재read하지 않음
7. structure read는 index_status: INDEX_INCOMPLETE일 때만 targeted fallback
8. MSC는 HLD .md inline이 아니라 별도 .puml 파일로 저장
9. HLD .md에는 msc_ref 링크와 산문 설명만 유지
```

---

## 3. v0.2 변경 요약

| 구분 | v0.1 | v0.2 |
|---|---|---|
| artifact 경로 | `%USERPROFILE%\artifacts\code_analyzer\<slug>`와 문서별 상대경로 혼재 | `output/5.2/<slug>/`로 전면 통일 |
| structure cache | Track B 저장 위치와 Track A 자동 탐색 위치 불일치 가능 | Track B/Track A/resume 모두 같은 canonical 경로 사용 |
| structure 자동 탐색 | 최신 structure를 무조건 열 수 있음 | focused 우선, full은 300KB 이하만 자동 사용 |
| 추출 방식 상태값 | shell_mode, git_bash, unknown 등 표현 혼재 가능 | `extraction_mode: git \| bash \| powershell \| internal_search \| mixed` |
| 진행줄 | 산문형 `Phase 0 완료` 중심 | 토큰형 `[진행: PHASE0_DONE → 다음: PHASE1_PROCEDURE_DISCOVERY]` |
| procedure 인계 | structure json 반복 read 가능 | Phase 1 `procedure_runtime_index` 생성 후 Phase 2는 index slice만 사용 |
| call edge 기록 | 전역 누적 본문 블록 가능 | 전역 본문 누적 제거, procedure별 기록 + 전역 id 요약만 허용 |
| MSC 저장 | HLD md 내부 PlantUML inline 가능 | 별도 `msc_<procedure_slug>_<ts>.puml` 파일로 통일 |
| Windows 호환성 | bash/find/grep 중심 | git → bash → powershell → internal_search fallback |
| CNF handler | 단일 handler 가정 | `ipc_cnf_handlers[]` 후보 배열 + procedure별 확정 |
| structure 크기 | 상한 불명확 | 300KB/1MB 기준 + focused structure 허용 |
| 실행 편의 | reference prompt 중심 | copy prompt 파일 추가 |
| schema | 문서 내부 설명 중심 | `schema/structure.schema.md`, `schema/analysis_progress.schema.md` 추가 |

---

## 4. 이 패키지가 RCA_standalone과 공유하는 것

- `START_HERE_5.2.md` 진입점 + `NEXT_STEP_5.2.md` 상태 파일
- overwrite 금지 + KST timestamp 산출물 규칙
- `[RN]` (Review Needed) 미확인 표기 — 추측 금지
- 한 번에 하나만 분석하는 staged execution
- 이력 문서 보존 (`review_logs/`)

---

## 5. 이 패키지가 RCA와 다른 것

- 입력이 로그가 아니라 **코드 + 블록명 또는 API명**
- 산출물이 case YAML이 아니라 **블록 단위 HLD성 분석 .md**
- 각 procedure는 별도 `.puml` 파일로 MSC를 저장하고, HLD .md에는 `msc_ref` 링크를 남김
- 런타임 yaml 없음. 상태는 `NEXT_STEP_5.2.md` + `output/5.2/<slug>/analysis_progress.md`로 충분하다고 판단

---

## 6. v0.2 범위

- Track A / Track B 프롬프트 안정화
- canonical output path 통일
- slug 생성 규칙 명문화
- extraction_mode enum 정리
- token progress cursor 도입
- Windows/PowerShell fallback 추가
- CNF handler 단일 가정 제거
- structure.json 크기 제한과 focused extraction 기준 추가
- 실행용 copy prompt 추가
- schema 문서 추가
- 런타임 반복 read 누수 차단
- procedure_runtime_index 도입
- MSC 분리형 `.puml` 산출물 통일

---

## 7. 알려진 미결

1. 실제 사내 L1 코드 1개 블록 대상 E2E 검증은 아직 별도 수행 필요.
2. 5.5 RCA `root_cause.code_ref`와 CodeAnalyzer 산출물 간 연결 계약은 첫 HLD 산출물 생성 이후 확정 권장.
3. Stage 분할 임계값은 실데이터 기준으로 보정 필요.

---

## 8. 권장 첫 검증 후보

```text
1. TxCfgMngr
2. ChannelConfigController
3. 특정 API 단건: XXX_SCellConfigReq 유형
```
