# NEXT_STEP — CodeAnalyzer Standalone 다음 행동

마지막 갱신: 2026-06-26 01:16 KST  
상태 파일: 이 파일 + `output/5.2/<slug>/analysis_progress.md`

---

## 1. 현재 상태

```text
current_block:             (없음)
current_slug:              (없음)
block_stack:               []          # 전환 시 복귀 대기 slug (LIFO). block_switch 참조
current_step:              INIT
next_step:                 TRACK_A_PHASE0
canonical_path:            output/5.2/<slug>/
selected_structure_json:   (없음 — Phase 0에서 focused 우선 자동 탐색 또는 생성)
structure_selection:       (없음)
extraction_mode:           (없음 — Track B 또는 Phase 0에서 확정)
runtime_read_policy:       progress_index_first; structure_targeted_fallback_only
progress_cursor:           [진행: INIT → 다음: TRACK_A_PHASE0]
```

---

## 2. 다음에 할 일

### 권장 (v0.5) — code-analyzer 스킬 사용

Claude Code에서 스킬을 호출한다. 부트스트랩 붙여넣기는 필요 없다(세션 불변 규칙이 스킬에 내장됨). 규모 판별(Track A/B)도 스킬이 자동으로 한다.

```text
/code-analyzer
또는 자연어: "이 코드루트의 <블록명 또는 API명> 분석해줘"
```

필요한 입력은 코드 루트와 분석 대상(블록명/API명) 둘뿐이다. 이어하기는 `/code-analyzer` 호출 후 "이어서"라고만 하면 current_slug에서 자동 복귀한다.

### 레거시 (수동 copy prompt) — 스킬 미설치 시

스킬이 없을 때만 사용한다. 새 세션이면 먼저 `prompt/copy_session_bootstrap.md`를 1회 붙여넣고, 작은 블록/API면 `prompt/copy_phase0.md`, 대형 코드면 `prompt/copy_track_b.md`로 시작한다. 이후 `prompt/copy_phase1.md`, `prompt/copy_next_procedure.md`, `prompt/copy_resume.md`, `prompt/copy_phase_f.md`를 진행줄 안내에 따라 사용한다.

---

## 3. Phase 0 완료 후 기대 결과

```text
output/5.2/<slug>/analysis_progress.md 생성 또는 갱신
output/5.2/<slug>/structure_<YYYYMMDD_HHMM_KST>_focused.json 확보
NEXT_STEP_5.2.md 갱신
```

진행줄 예:

```text
[진행: PHASE0_DONE → 다음: PHASE1_PROCEDURE_DISCOVERY]
```

---

## 4. Phase 1 완료 후 기대 결과

```text
analysis_progress.md 안에 procedure 목록 생성
analysis_progress.md 안에 procedure_runtime_index 생성
전역 confirmed call edges 누적 본문 블록 없음
```

진행줄 예:

```text
[진행: PHASE1_DONE → 다음: PROC_NEXT:<procedure_slug>]
```

---

## 5. Phase 2..N 완료 후 기대 결과

```text
procedure별 결과 섹션 갱신
output/5.2/<slug>/msc_<procedure_slug>_<YYYYMMDD_HHMM_KST>.puml 생성
hld_<...>.md에는 msc_ref 링크와 동작 설명만 반영
structure json 전체 반복 read 없음
```

진행줄 예:

```text
[진행: PROC_DONE:<procedure_slug> → 다음: PROC_NEXT:<next_procedure_slug>]
[진행: PROC_DONE:<procedure_slug> → 다음: PHASEF_FINALIZE]
```

---

## 6. 상태 전이 참조

```text
INIT
  → TRACK_B_STRUCTURE_EXTRACTION      (선택)
  → TRACK_A_PHASE0                    (구조맵 확보 + Stage 계획)
  → PHASE1_PROCEDURE_DISCOVERY        (procedure 목록 + procedure_runtime_index 생성)
  → PROC_NEXT:<procedure_slug>        (procedure별 분석)
  → PHASEF_FINALIZE                   (블록 HLD 마무리)
  → WAIT_NEW_BLOCK                    (다음 블록 입력 대기)

블록 전환 (분석 중 다른 블록 끼어들기, v0.5):
  PROC_NEXT:<slug> 중
  → BLOCK_SWITCH_PUSH:<old_slug>      (현재 cursor 보존 + block_stack push)
  → PHASE0:<new_slug>                 (새 블록 분석)
  → BLOCK_SWITCH_POP                  (block_stack pop → 이전 slug·cursor 복귀)
  상세: skills/code-analyzer/references/block_switch.md
```

---

## 7. 고정 규칙

```text
경로: output/5.2/<slug>/
추출 enum: extraction_mode: git | bash | powershell | internal_search | mixed
진행줄: token progress cursor 형식
structure 자동 탐색: focused 우선, full은 300KB 이하만 자동 사용
runtime read: procedure_runtime_index 우선, structure는 targeted fallback only
MSC: 별도 .puml 파일, HLD md에는 msc_ref만 기록
```

위 규칙은 v0.2의 필수 고정 규칙이다.
