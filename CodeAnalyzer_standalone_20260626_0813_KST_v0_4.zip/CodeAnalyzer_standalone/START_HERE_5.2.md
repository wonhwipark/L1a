# START_HERE — CodeAnalyzer Standalone 사용자 시작점

작성일: 2026-06-26 01:16 KST  
대상: 사내 PC, VSCode + Claude Code/Roo Code, `CodeAnalyzer_standalone` 폴더

이 파일은 처음 실행자가 **어느 문서를 먼저 보고 무엇을 해야 하는지**만 안내한다.  
상세 설계 이력은 `HANDOFF_5.2.md`, 막혔을 때 분기는 `RUNBOOK_BLOCK_TO_HLD_5.2.md`를 본다.

---

## 문서 지도 — 평소에는 이 파일 하나면 된다

```text
START_HERE_5.2.md   ← 지금 이 파일. 처음/평소엔 여기만 본다.
NEXT_STEP_5.2.md    ← 지금 상태와 다음 한 줄. 이어서 할 때 본다.
RUNBOOK_*.md        ← 막혔을 때만 본다 (증상 → 조치 표).
prompt/             ← 실제로 복사해서 붙여넣는 파일들.
나머지(VERSION/HANDOFF/RUNTIME_TOKEN_POLICY/schema/reference)
                    ← 설계 이력·계약. 평소엔 안 봐도 된다.
```

처음이면 아래 §3 순서표만 따라가면 된다.

---

## 0. v0.3 핵심 변경 — 산출물 경로를 `output/`으로 이동

v0.3부터 모든 산출물은 아래 상대경로만 사용한다.

```text
output/5.2/<slug>/
```

Track B가 `structure_*.json`을 쓰는 위치, Track A Phase 0이 `structure_*.json`을 찾는 위치, `analysis_progress.md`가 저장되는 위치, resume 시 읽는 위치가 모두 같아야 한다.

아래 경로는 폐기한다.

```text
%USERPROFILE%\artifacts\code_analyzer\<slug>\
artifacts\code_analyzer\<slug>\
artifacts/5.2/<slug>/        # v0.2 경로. v0.3에서 output/5.2/로 이동
```

이 규칙이 깨지면 Track B → Track A 자동 인계와 resume이 깨진다.

### v0.2 → v0.3 마이그레이션

v0.2로 이미 만든 산출물이 있으면 한 번만 폴더명을 바꾼다.

```powershell
# 패키지 루트에서 1회 실행
if (Test-Path .\artifacts\5.2) { Move-Item .\artifacts\5.2\* .\output\5.2\ -Force }
```

진행 중이던 작업은 `output/5.2/<slug>/analysis_progress.md`를 그대로 이어서 쓰면 된다. 경로 문자열만 바뀌고 내용 계약은 동일하다.

---

## 1. v0.2 추가 핵심 — 런타임 반복 read 누수 차단

copy prompt 분리만으로 reference prompt 입력 토큰은 줄었다. 그러나 procedure가 늘어날수록 `analysis_progress.md`와 `structure_focused.json`을 반복해서 통째로 읽으면 토큰이 다시 증가한다.

그래서 v0.2는 아래 정책을 적용한다.

```text
1. 전역 confirmed call edges 누적 본문 블록 제거
2. procedure별 call edge는 각 procedure 섹션 내부에만 기록
3. 전역에는 필요 시 EDGE001 같은 id만 요약
4. Phase 1이 procedure_runtime_index를 생성
5. Phase 2..N은 procedure_runtime_index에서 해당 procedure slice만 읽음
6. structure_focused.json은 매 procedure마다 다시 읽지 않음
7. MSC는 HLD .md에 inline하지 않고 별도 .puml 파일로 저장
```

---

## 2. 이 도구가 만드는 것

```text
L1 C++ 코드 + 블록명 또는 API명
  → Track A staged 분석
  → 블록 단위 HLD성 분석 .md
       ├─ 블록 개요
       ├─ procedure 1 → msc_ref(.puml) + 동작 설명
       ├─ procedure 2 → msc_ref(.puml) + 동작 설명
       └─ procedure N
```

원칙:

```text
1 블록 = HLD성 .md 1개
1 procedure = MSC .puml 1개
미확인 flow = [RN] 표시
산출물 overwrite 금지
```

---

## 3. 처음 열면 이 순서만 따르면 된다

| 순서 | 할 일 | 보는 파일 | 결과 |
|---:|---|---|---|
| 1 | VSCode에서 `CodeAnalyzer_standalone` 폴더 자체를 연다 | - | 상대경로 정상화 |
| 2 | 현재 상태를 확인한다 | `NEXT_STEP_5.2.md` | 다음 단계 확인 |
| 3 | 사내 스킬 설치를 확인한다 | 아래 §5 | 스킬 가용 확인 |
| 4 | 세션 시작 시 공통 규칙을 1회 붙여넣는다 | `prompt/copy_session_bootstrap.md` | 이후 단계 prompt 단축 (토큰 절감) |
| 5 | 작은 블록/API면 Track A 실행 | `prompt/copy_phase0.md` | Phase 0 시작 |
| 6 | 대형 코드면 Track B 선행 | `prompt/copy_track_b.md` | structure cache 생성 |
| 7 | Phase 1부터는 copy prompt만 사용 | `prompt/copy_phase1.md`, `prompt/copy_next_procedure.md`, `prompt/copy_resume.md` | reference prompt 반복 read 방지 |
| 8 | 막히면 RUNBOOK 확인 | `RUNBOOK_BLOCK_TO_HLD_5.2.md` | 분기 조치 |

주의:

```text
prompt/5.2_track_a_prompt.md
prompt/5.2_track_b_prompt.md
```

위 두 파일은 reference 문서다. 런타임 실행에는 copy prompt만 사용한다.

---

## 4. Track A / Track B 선택 기준

| 상황 | 권장 |
|---|---|
| 특정 API 하나만 분석 | Track A 바로 실행 |
| 블록이 10파일 이하로 예상 | Track A 바로 실행 |
| 블록이 20파일 이상 또는 5천 LOC 이상 | Track B 먼저 권장 |
| 코드루트 전체가 수백~수천 파일 | Track B 먼저 실행 |
| 어느 블록인지도 모름 | Track B로 후보 구조 먼저 확인 |

Track B는 필수가 아니라 선택적 전처리다. 단, 대형 코드에서는 토큰 절감을 위해 Track B 선행이 유리하다.

---

## 5. 선행 — 스킬 설치 확인

이 패키지는 스킬 본체를 포함하지 않는다. 사내 설치 전제다.

```powershell
# 3개 스킬이 모두 설치되어 있는지 한 번에 확인. ALL_OK가 나오면 통과.
$skills = @("staged-code-analyzer","api-callflow-analysis","plantuml-msc")
$missing = $skills | Where-Object { -not (Test-Path "$env:USERPROFILE\.claude\skills\$_\SKILL.md") }
if ($missing) { "MISSING: $($missing -join ', ')" } else { "ALL_OK" }
```

`MISSING:`가 출력되면 해당 사내 스킬 설치 절차를 먼저 진행한다.

---

## 6. slug 규칙

`slug`는 output 경로를 결정하는 키다. Track A/B/resume 모두 같은 slug를 써야 한다.

```text
canonical output directory = output/5.2/<slug>/
```

생성 규칙:

```text
1. 사용자가 target slug를 주면 그 값을 최우선 사용
2. 없으면 block_or_api 이름에서 자동 생성
3. 소문자 변환
4. 공백, /, \, :, ., -, (, ), [, ], {, } 는 _ 로 변환
5. 연속 _ 는 하나로 축약
6. 앞뒤 _ 제거
```

예:

| 입력 | slug |
|---|---|
| `Tx Config Manager` | `tx_config_manager` |
| `TxCfgMngr` | `txcfgmngr` |
| `XXX_SCellConfigReq` | `xxx_scellconfigreq` |
| `NR/LTE Tx-Switch` | `nr_lte_tx_switch` |

**slug 자동 승계(v0.4):** Phase 0이 slug를 확정하면 `NEXT_STEP_5.2.md`의 `current_slug`에 기록한다. 이후 `copy_phase1`/`copy_next_procedure`/`copy_resume`/`copy_phase_f`는 slug를 비워두면 이 값을 자동 승계한다. 사람이 매 단계 slug를 다시 적을 필요가 없다. 다른 블록으로 바꿀 때만 slug를 새로 지정한다.

---

## 7. 사용자가 직접 편집해도 되는 / 안 되는 파일

산출물 구조(`output/5.2/<slug>/` 하위 파일명과 의미)는 스킬 `staged-code-analyzer`가 소유한다. 사람은 아래 범위만 직접 손댄다.

### 직접 편집 가능

```text
prompt/*.md                          # 프롬프트 정책 조정 시
output/5.2/<slug>/hld_*.md           # 사람이 머지/정리 판단 시
```

### 자동 갱신 파일 (스킬/Track A가 생성·갱신)

```text
NEXT_STEP_5.2.md
output/5.2/<slug>/analysis_progress.md
output/5.2/<slug>/structure_*.json
output/5.2/<slug>/msc_*.puml
```

`analysis_progress.md`는 사람이 직접 편집하지 않는 것을 원칙으로 한다. 단, procedure 범위 선택과 머지 판단은 사용자가 결정한다. 산출물 폴더의 정식 layout은 `output/5.2/_example_slug/README.md`를 참고한다.

---

## 8. 최소 실행 루프

```text
(선택) Track B
  → output/5.2/<slug>/structure_<ts>_focused.json 생성

Track A Phase 0
  → canonical 경로에서 focused 우선으로 structure 확보
  → output/5.2/<slug>/analysis_progress.md 생성

Track A Phase 1
  → 블록 수신 핸들러 열거
  → procedure 목록 제시
  → 사용자가 범위 1회 선택
  → procedure_runtime_index 생성

Track A Phase 2..N
  → procedure_runtime_index의 해당 slice만 읽음
  → procedure별 call flow 추적
  → msc_<procedure_slug>_<ts>.puml 생성
  → hld_<...>.md에는 msc_ref와 동작 설명만 누적

Track A Phase F
  → 블록 HLD성 .md 마무리
```

---

## 9. 진행줄 규칙

모든 응답 마지막은 token progress cursor를 사용하고, 바로 다음 줄에 **다음에 붙여넣을 파일**을 안내한다(v0.4).

```text
[진행: PHASE0_DONE → 다음: PHASE1_PROCEDURE_DISCOVERY]
▶ 다음 붙여넣기: prompt/copy_phase1.md

[진행: PHASE1_DONE → 다음: PROC_NEXT:<procedure_slug>]
▶ 다음 붙여넣기: prompt/copy_next_procedure.md

[진행: PROC_DONE:<procedure_slug> → 다음: PROC_NEXT:<next_procedure_slug>]
▶ 다음 붙여넣기: prompt/copy_next_procedure.md

[진행: PROC_DONE:<procedure_slug> → 다음: PHASEF_FINALIZE]
▶ 다음 붙여넣기: prompt/copy_phase_f.md

[진행: BLOCK_HLD_DONE:<slug> → 다음: WAIT_NEW_BLOCK]
▶ 다음 블록을 분석하려면: prompt/copy_phase0.md
```

이렇게 하면 사용자가 "지금 어느 파일을 열어야 하지"를 스스로 판단하지 않아도 된다.

산문형 진행줄은 쓰지 않는다.

```text
[진행: Phase 0 완료 → 다음: Phase 1 예정]   # 사용 금지
```
