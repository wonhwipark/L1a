# P0 — 환경 자가 진단 + 상태 파일 초기화

가장 먼저 1회. 추측하지 말고 실제 파일시스템을 확인해 환경을 진단하고 current_run.yaml에 저장한다.

조사:
1. 작업 루트가 RCA_standalone 폴더인지 확인.
2. 이 폴더 및 일반 로그 후보 경로에서 `.sdm`과 `_l1sw.txt`를 찾는다(경로·크기·수정시각 표). `_l1sw.txt`가 1개면 `input.selected_l1sw_txt`에 자동 저장, 여러 개면 번호 목록 + next_step=C0_SELECT_L1SW_TXT, 없고 `.sdm`만 있으면 next_step=C0_RUN_L1SW.
3. L1SW Log Analyzer 접근성 확인: parse.ps1 후보, manifest 디렉토리·fragment JSON. `l1sw` 블록에 저장.
4. PowerShell 실행 가능 여부 + `scripts/*_prefilter.ps1` 파라미터 구조 확인(이 단계에서 prefilter 실행 안 함).
5. `rca_kg/cases/` 아래 EXAMPLE 외 실제 case 수.
6. `signals_tool_generate/`, `indexes_tool_generate/` 상태.
7. START_HERE_5.5.md, NEXT_STEP_5.5.md, current_run.yaml 존재 확인.

출력:
- 화면: `| 항목 | 상태(OK/없음/확인불가) | 근거 경로 | 다음 조치 |` 표.
- `review_logs/p0_env_probe_<YYYYMMDD>_<HHMM>_KST.md` 생성(타임스탬프 도구가 채움).
- current_run.yaml을 실제 값으로 갱신. NEXT_STEP_5.5.md 갱신.

next_step 판정: `_l1sw.txt` 1개 선택가능→P1 / 여러 개→C0_SELECT_L1SW_TXT / 없고 .sdm+parse.ps1→C0_RUN_L1SW / parse.ps1 못 찾음→P0_NEEDS_L1SW_PATH.

마지막에 "지금 P1부터 시작 가능한가?"를 yes/no로 판정. no면 사람이 먼저 할 최소 작업만 1~3줄.
[사람 확인] P0 표의 "다음 조치"와 NEXT_STEP만 확인.
