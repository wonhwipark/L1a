# START_HERE — RCA Standalone 사용자 시작점 (5.5)

작성일: 2026-06-25 01:38 KST  
대상: 사내 PC, VSCode + Claude Code, `RCA_standalone` 폴더

이 파일은 처음 실행자가 **어느 문서를 먼저 봐야 하는지, 지금 무엇을 해야 하는지**만 안내한다.  
상세 이유와 설계 이력은 `HANDOFF_5.5.md`, 전체 설명은 `USAGE_SCENARIO_5.5.md`, 단계별 손동작은 `RUNBOOK_L1SW_TO_P6_5.5.md`를 본다.

이 패키지는 **5.5 RCA** 트랙이다. 5.2 CodeAnalyzer 패키지와 한 작업공간에 같이 둘 수 있도록 최상위 문서는 모두 `_5.5` 접미사를 쓴다.

---

## 문서 지도 — 평소에는 이 파일 하나면 된다

```text
START_HERE_5.5.md   ← 지금 이 파일. 처음/평소엔 여기만 본다.
USER_GUIDE_5.5.md   ← 상세 사용법. 파이프라인·P0~P6·이어하기·정직성 원칙 전체.
NEXT_STEP_5.5.md    ← 지금 상태와 다음 P단계. 이어서 할 때 본다.
RUNBOOK_*_5.5.md    ← 막혔을 때만 본다 (분기표).
prompt/             ← Claude Code에 붙여넣는 P0~P6 본문.
나머지(VERSION/HANDOFF/USAGE_SCENARIO/rca_kg/schema 등)
                    ← 설계 이력·계약. 평소엔 안 봐도 된다.
```

---

## 0. 핵심 원칙

```text
.sdm 원본 로그
  → L1SW Log Analyzer
  → _l1sw.txt
  → RCA P3~P6
  → case YAML / keywords.yaml 성장
```

RCA는 `.sdm` 원본을 직접 분석하지 않는다.  
RCA의 주 입력은 L1SW가 만든 `_l1sw.txt` 또는 P3가 만든 `signals_tool_generate/*_signal.txt`다.

---

## 1. 처음 열면 이 순서만 따르면 된다

### 권장 (v0.16) — root-cause-analyzer 스킬

| 순서 | 할 일 | 보는 파일 | 결과 |
|---:|---|---|---|
| 1 | VSCode에서 `RCA_standalone` 폴더 자체를 연다 | - | `@상대경로`가 정상 동작 |
| 2 | root-cause-analyzer 스킬을 설치한다(1회) | 아래 §8 | `/root-cause-analyzer` 사용 가능 |
| 3 | 스킬을 호출한다 | `/root-cause-analyzer` 또는 "이 _l1sw.txt 원인 분석해줘" | P0부터 자동 진행 |

스킬이 알아서 하는 것: 공통 운영 규칙 자동 적용(부트스트랩 붙여넣기 불필요), P0 환경 진단, current_run.yaml 기반 단계 자동 진행, issue_type 자동 추천, 미지 모듈 가드. 사람은 각 단계의 `[사람 확인]` 지점에서만 한 줄로 답하면 된다.

### 레거시 (수동 P0~P6) — 스킬 미설치 시

| 순서 | 할 일 | 보는 파일 |
|---:|---|---|
| 1 | 폴더를 연다 | - |
| 2 | 상태 확인 | `NEXT_STEP_5.5.md` |
| 3 | P0 블록 붙여넣기 | `prompt/CLAUDE_CODE_PROMPTS_e2e_v1.md` |
| 4 | NEXT_STEP이 안내하는 다음 P단계 실행 | `NEXT_STEP_5.5.md` |
| 5 | 막히면 RUNBOOK 분기표 | `RUNBOOK_L1SW_TO_P6_5.5.md` |

---

## 2. 이 패키지에서 사용자가 직접 편집해도 되는 파일 / 안 되는 파일

### 사용자가 직접 편집해도 되는 파일

```text
rca_kg/keywords.yaml                  # P6 전후 검토/보강 가능. 단, P6 권장.
rca_kg/cases/*.yaml                   # P5 승인/수정 대상
rca_kg/cases/unresolved/*.yaml         # 이관/미결 보강 대상
```

### 사용자가 직접 편집하지 않는 자동 전용 파일

```text
rca_kg/runtime_tool_generate/current_run.yaml
NEXT_STEP_5.5.md
rca_kg/signals_tool_generate/*
rca_kg/indexes_tool_generate/index.md
rca_kg/manifest_fragments/*
```

`*_tool_generate`은 **Claude Code/스크립트가 생성·갱신하는 폴더**라는 뜻이다. 사람이 직접 편집하지 않는다. 다만 승인, 원인 판단, 추가 추출 여부 결정은 여전히 사람이 한다. 즉 "도구가 쓰고, 사람이 판단한다".

---

## 3. 현재 패키지의 기본 시작 상태

현재 패키지는 아래 상태 파일을 포함한다.

```text
rca_kg/runtime_tool_generate/current_run.yaml
```

처음에는 `next_step: P0` 상태다.  
P0가 실행되면 이 파일에 L1SW 경로, `_l1sw.txt` 후보, `.sdm` 후보, 현재 단계가 기록된다. 이후 P1~P6는 이 파일을 읽고 갱신한다.

---

## 4. 최소 실행 루프

```text
P0  환경 진단 + current_run.yaml 생성/갱신
C0  _l1sw.txt 확보. 없으면 L1SW parse.ps1 1회 실행
P1  _l1sw.txt 형식 역설계
P2  L1SW manifest fragment 후보 생성
P3  issue_type 추천 + signal 생성
P4  원인분석 + case YAML 생성/갱신
P5  자가점검 + 사람 승인
P6  keywords.yaml candidate → confirmed 승격
```

각 단계 종료 후 Claude Code는 반드시 아래 두 가지를 갱신해야 한다.

```text
rca_kg/runtime_tool_generate/current_run.yaml
NEXT_STEP_5.5.md
```

---

## 5. 실행 전 자체 검증

패키지 문서/경로 정합성을 점검하려면 PowerShell에서 실행한다.

```powershell
cd "<RCA_standalone_경로>"
.\scripts\validate_package.ps1
```

검증 대상:

```text
- START_HERE_5.5.md 존재 여부
- current_run.yaml / current_run.example.yaml 존재 여부
- NEXT_STEP_5.5.md 존재 여부
- active 문서의 옛 signals 경로 잔존 여부
- taxonomy와 skills_seed root_cause category 정합성
- keywords.yaml 기본 구조 존재 여부
```

---

## 6. 문서 역할

| 파일 | 역할 |
|---|---|
| `START_HERE_5.5.md` | 처음 보는 사용자의 진입점 |
| `skills/root-cause-analyzer/` | v0.16 스킬 본체(SKILL.md + references). 설치 후 `/root-cause-analyzer` |
| `NEXT_STEP_5.5.md` | 현재 상태 기준 다음 행동 안내 |
| `RUNBOOK_L1SW_TO_P6_5.5.md` | L1SW 연동부터 P6까지 순서와 손동작 |
| `prompt/CLAUDE_CODE_PROMPTS_e2e_v1.md` | 레거시 수동 P0~P6 프롬프트(스킬 미설치 시) |
| `USAGE_SCENARIO_5.5.md` | 전체 사용 시나리오와 운영 모드 |
| `HANDOFF_5.5.md` | 설계 결정 이력과 다음 세션 인계 |
| `scripts/README.md` | 수동형 PowerShell 운영 상세 |
| `prompt/deepdive/RCA_ANALYSIS_METHODOLOGY.md` | P4 원인분석 추론법(SSOT) |

---

## 7. 스킬 설치 (1회)

v0.16부터 이 패키지는 `root-cause-analyzer` 스킬 본체를 포함한다(`skills/root-cause-analyzer/`). 사용자 스킬 폴더로 복사하면 `/root-cause-analyzer`로 바로 쓸 수 있다.

```powershell
# 패키지 루트에서 1회 실행. 이미 있으면 갱신.
$dst = "$env:USERPROFILE\.claude\skills\root-cause-analyzer"
New-Item -ItemType Directory -Force -Path $dst | Out-Null
Copy-Item -Recurse -Force ".\skills\root-cause-analyzer\*" $dst
if (Test-Path "$dst\SKILL.md") { "ALL_OK" } else { "MISSING" }
```

L1SW Log Analyzer는 별도 스킬이다. RCA는 그 산출물 `_l1sw.txt`를 입력으로 받을 뿐이며, 스킬은 L1SW를 직접 실행하지 않고 필요한 경우 실행 명령을 안내한다(C0).

---

## 8. 상세 사용법

### 8.1 한눈에 보는 전체 흐름

```text
.sdm ─[L1SW Log Analyzer]→ _l1sw.txt ─[root-cause-analyzer]→ case YAML / keywords 성장

P0 환경 진단 ─(C0 _l1sw 확보)─ P1 형식 역설계 ─ P2 manifest 후보
  └ 여기까지는 환경/형식 준비. 보통 1회만.
P3 issue_type 추천+signal ─ P4 원인분석+case ─ P5 자가점검+승인 ─ P6 keywords 승격
  └ 실제 로그마다 반복하는 본 루프 (P3 → P4 → P5 → P6)
```

### 8.2 처음 시작 (스킬)

1. §7로 스킬을 1회 설치한다.
2. Claude Code에서 `RCA_standalone` 폴더를 연다.
3. 입력 로그를 준비한다.
   - 이미 `_l1sw.txt`가 있으면 폴더 안이나 알려진 경로에 둔다.
   - `.sdm`만 있으면 그대로 둔다. P0가 감지해서 C0(L1SW 실행)를 안내한다.
4. `/root-cause-analyzer` 호출. 또는 "이 _l1sw.txt 원인 분석해줘".
5. 스킬이 P0(환경 진단)를 수행하고, `_l1sw.txt` 유무에 따라 자동 분기한다.

### 8.3 각 단계에서 사용자가 할 일 (`[사람 확인]` 지점)

스킬은 단계를 자동 진행하되 아래 지점에서만 멈추고 한 줄로 묻는다.

```text
P0  →  표의 "다음 조치"와 NEXT_STEP 확인
C0  →  _l1sw.txt 경로가 맞는지만
P1  →  cptime 포맷 한 줄이 실제 로그와 맞는지
P2  →  manifest 기존 구조와 일치하는지
P3  →  추천된 issue_type과 signal 줄 수 ("이걸로 진행할까요?"에 yes/no)
P4  →  인과사슬 1줄, confidence, case 파일 경로
P5  →  승인 가능하면 "승인" 한 단어
P6  →  before/after 표에서 승격 대상이 과하지 않은지
```

그 외 경로·타임스탬프·slug·issue_type 자동선택은 사람이 입력하지 않는다.

### 8.4 이어하기 / 반복

- **중단 후 이어하기:** `/root-cause-analyzer` 호출 후 "이어서". current_run.yaml의 next_step에서 자동 복귀한다.
- **새 로그 분석:** P2까지 끝났으면, 다음 로그는 P3부터 돈다. "이 새 _l1sw.txt P3부터 돌려줘"라고 하면 된다.
- **issue_type 직접 지정:** 자동 추천 대신 직접 고르려면 "scg_failure로 분석해줘"처럼 지정한다.

### 8.5 분석 정직성 (스킬이 지키는 안전장치)

```text
- 미지 모듈 가드: 원인 줄이 로그에 안 보이면 confidence를 올리지 않는다.
  추가 추출을 제안하고 멈춘다. 2회 후에도 없으면 "원인 미상 + confidence: low"로 정직 종료.
- unresolved(담당영역 밖, 핸드오프) ≠ low(저신뢰). 구분해서 처리한다.
- 순서 판단은 wall-clock이 아니라 항상 cptime.
- crash/dump는 RCA 대상 아님 (L1SW 전담).
```

### 8.6 막히면

- 다음에 뭘 할지 모르겠다 → `NEXT_STEP_5.5.md`.
- 단계가 꼬였다 / 분기 판단 → `RUNBOOK_L1SW_TO_P6_5.5.md`.
- P4 추론이 막힌다 → `prompt/deepdive/RCA_ANALYSIS_METHODOLOGY.md`(SSOT).
- 스킬이 안 떠서 수동으로 → `prompt/CLAUDE_CODE_PROMPTS_e2e_v1.md`의 해당 P블록.

### 8.7 레거시(수동) 방식

스킬이 설치되지 않은 환경에서는 `prompt/CLAUDE_CODE_PROMPTS_e2e_v1.md`의 P0 블록부터 순서대로 붙여넣는다. 공통 운영 규칙도 그 파일 상단에 있다. 동작 결과는 스킬과 동일하다(스킬은 그 프롬프트들을 자동화한 것일 뿐).
