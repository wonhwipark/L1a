# NEXT_STEP — RCA Standalone 다음 행동

마지막 갱신: 2026-06-25 01:38 KST  
상태 파일: `rca_kg/runtime_tool_generate/current_run.yaml`

## 현재 상태

```text
current_step: INIT
next_step: P0
```

## 다음에 할 일

### 권장 (v0.16) — root-cause-analyzer 스킬

Claude Code에서 스킬을 호출한다. 부트스트랩 붙여넣기 불필요(공통 운영 규칙이 스킬에 내장). P0부터 current_run.yaml 따라 자동 진행한다.

```text
/root-cause-analyzer
또는 자연어: "이 _l1sw.txt 원인 분석해줘"
```

이어하기는 호출 후 "이어서"라고만 하면 next_step에서 자동 복귀한다.

### 레거시 (수동 P0~P6) — 스킬 미설치 시

`prompt/CLAUDE_CODE_PROMPTS_e2e_v1.md`의 **P0 — 환경 자가 진단** 블록부터 순서대로 붙여넣는다.

## P0 완료 후 기대 결과

```text
- rca_kg/runtime_tool_generate/current_run.yaml 갱신
- NEXT_STEP_5.5.md 갱신
- review_logs/p0_env_probe_<YYYYMMDD>_<HHMM>_KST.md 생성
```

## 사용자가 확인할 것

P0 응답 마지막의 진행 줄을 본다.

```text
[진행: P0 완료 → 다음: C0 또는 P1. ...]
```

`_l1sw.txt`가 없으면 C0 단계에서 L1SW 실행 명령을 안내받는다.  
`_l1sw.txt`가 이미 있으면 P1로 진행한다.
