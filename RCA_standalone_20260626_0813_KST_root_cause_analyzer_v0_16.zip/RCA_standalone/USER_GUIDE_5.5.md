# USER_GUIDE_5.5 — root-cause-analyzer 사용 가이드

버전: v0.16  
대상: L1 채널 모뎀 프로토콜 로그 근본 원인 분석 (RCA)  
스킬: `root-cause-analyzer` (`/root-cause-analyzer`)  
issue_type: RACH failure · SCG failure · TX abnormal · L2 max retransmission

---

## 1. 입력 파이프라인 (RCA가 하는 일과 안 하는 일)

```
.sdm 원본
  → [L1SW Log Analyzer]  ← 별도 스킬. RCA 밖.
  → _l1sw.txt            ← RCA의 주 입력
  → [P0 ~ P6]            ← 이 스킬
  → case YAML / keywords.yaml 성장
```

RCA는 `.sdm`을 직접 읽지 않는다.  
`_l1sw.txt`가 없으면 P0가 L1SW 실행 명령을 안내한다(C0). 파라미터가 확실할 때만 자동 실행한다.

---

## 2. 준비 (최초 1회)

### 2.1 스킬 설치

패키지 루트(`RCA_standalone/`)에서 PowerShell 실행.

```powershell
$dst = "$env:USERPROFILE\.claude\skills\root-cause-analyzer"
New-Item -ItemType Directory -Force -Path $dst | Out-Null
Copy-Item -Recurse -Force ".\skills\root-cause-analyzer\*" $dst
if (Test-Path "$dst\SKILL.md") { "OK" } else { "MISSING" }
```

`OK` 출력 후 **VSCode를 완전 재시작**한다.

### 2.2 폴더 열기

VSCode에서 `RCA_standalone/` 폴더 **자체**를 연다.  
(`@rca_kg/...` 등의 상대경로가 이 폴더 기준으로 동작한다.)

---

## 3. 단계 개요

단계는 **환경 준비(P0~P2)**와 **분석 루프(P3~P6)**로 나뉜다.

```
P0  환경 진단 + current_run.yaml 초기화  ← _l1sw.txt 유무 판단
 └ C0  _l1sw.txt 확보 (없을 때만)
P1  _l1sw.txt 출력 형식 역설계           ← cptime 포맷 파악
P2  manifest fragment 후보 생성          ← L1SW 필터 정의
──── 여기까지 환경·형식 준비. 보통 1회만. ─────────────────
P3  issue_type 추천 + signal 생성        ← 로그마다 반복 시작
P4  원인분석 7단계 + case YAML 생성/갱신
P5  자가점검 + 승인 정규화
P6  keywords candidate → confirmed 승격
```

두 번째 로그부터는 **P3부터** 시작한다.

---

## 4. 처음 시작

### 4.1 호출

```
/root-cause-analyzer
```

또는 자연어:

```
C:\logs\ue01_20260626_l1sw.txt 원인 분석해줘
```

스킬이 `current_run.yaml`과 `NEXT_STEP_5.5.md`를 읽어 현재 상태를 파악한다.  
첫 실행이면 P0부터, 진행 중이면 `next_step`에서 자동 복귀한다.

### 4.2 P0 — 환경 진단 `[사람 확인]`

```
[자동] 폴더 스캔:
  _l1sw.txt: C:\logs\ue01_20260626_l1sw.txt (2.3MB) ✓
  manifest_fragments: 없음 → P2 필요(1회)
  → review_logs/p0_env_probe_<KST>.md 생성

| 항목              | 상태 | 조치         |
|-------------------|------|--------------|
| _l1sw.txt         | OK   | P1 진행 가능 |
| manifest_fragments| 없음 | P2 필요(1회) |
| cases/            | 0건  | 정상         |
```

→ 사람: 표 확인 후 이상 없으면 그냥 진행 (또는 수정 지시)

`_l1sw.txt`가 없으면:
- `.sdm`과 `parse.ps1`이 있으면 C0가 실행 명령을 제시한다.
- 둘 다 없으면 C0가 파일 배치 방법을 안내한다.

### 4.3 P1 — 형식 역설계 `[사람 확인]`

`_l1sw.txt` 앞 50줄 + 무작위 30줄을 읽어 cptime 포맷과 모듈 필드 위치를 파악한다.  
결과를 `prompt/deepdive/L1SW_OUTPUT_FORMAT_PROBED_<KST>.md`에 저장한다.

→ 사람: "cptime 포맷이 실제 로그와 맞는지" 한 줄 확인

### 4.4 P2 — manifest fragment 생성 `[사람 확인]`

`keywords.yaml` 기반으로 issue_type별 L1SW 필터 후보 JSON을 자동 생성한다.  
`keywords.yaml` 자체는 수정하지 않는다.

→ 사람: review_log의 "기존 구조 일치 여부"만 확인

---

## 5. 분석 루프 (로그마다 반복: P3 → P4 → P5 → P6)

### 5.1 P3 — issue_type 추천 + signal 생성 `[사람 확인]`

4개 issue_type 대표 signature 등장 횟수를 카운트해 자동 추천한다.

```
[자동] issue_type 카운트:
  rach_failure      hit 47  ← 최다
  scg_failure       hit  3
  tx_abnormal       hit  1
  l2_max_retrans    hit  0

→ rach_failure 로 진행할까요?
```

→ 사람: `응` (또는 `scg_failure` 등 직접 지정 가능)

확정 후 `scripts/rach_prefilter.ps1` (또는 keywords.yaml 기반 임시 필터)로 signal 파일을 생성한다.

```
signals_tool_generate/20260626_rach_failure_ue01_signal.txt (312줄)
cptime 범위: 0x1A3F00 ~ 0x1A4200
미지 모듈 가드: RACH/MAC/PHY 보임 → 좁지 않음 ✓
```

### 5.2 P4 — 원인분석 7단계 + case YAML `[사람 확인]`

signal 파일을 기준으로 7단계 추론을 수행한다.

| 단계 | 내용 |
|---|---|
| S1 증상 고정 | 최초 실패 cptime을 anchor로 |
| S2 시간창 | anchor 앞·뒤로 cptime 구간 설정 |
| S3 정상경로 대조 | seed의 happy-path 대비 최초 이탈 지점 |
| S4 가설 | 2~4개 후보 |
| S5 가르기 | 가설 구분하는 단서만 추가 확인 |
| S6 범위 분리 | L1 담당 vs 환경/RF/단말 판단 |
| S7 인과사슬 | "A 때문에 B가 발생, 결과로 C 실패" + confidence 산정 |

분석 후 case YAML을 생성하거나 기존 case에 occurrence를 추가한다.

→ 사람: 인과사슬 1줄 + confidence + 파일 경로 확인

**미지 모듈 가드**: 원인 줄이 로그에 없으면 원인을 단정하지 않고 추가 추출을 제안한다. 2회 후에도 없으면 `confidence: low + 원인 미상`으로 정직 종료한다.

**담당영역 밖** (RF·환경·단말 등): `unresolved` + handoff 처리. `confidence: low`와는 다른 상태다.

### 5.3 P5 — 자가점검 + 승인 `[사람 확인]`

case YAML에 대해 11개 항목을 자가점검한다.

```
✓ issue_type taxonomy active
✓ category applies_to 일치
✓ confidence 증거 수준 적정
✓ fingerprint signature가 keywords.yaml ID
✓ generic signature 미포함
✓ cptime 상대 순서
✓ 금지 필드(line_range/time_range 등) 없음
...

→ 이상 없음. 승인할까요?
```

→ 사람: `승인`

승인 시: `review.status: reviewed`, `fingerprint.sequence_status: confirmed`.

### 5.4 P6 — keywords 승격 `[사람 확인]`

P5 승인된 case의 근거 signature를 `keywords.yaml`에 반영한다.

```
| signature         | before    | after     |
|-------------------|-----------|-----------|
| RACH_MSG2_TIMEOUT | candidate | confirmed |
```

→ 사람: before/after 표에서 승격 대상이 과하지 않은지 확인

완료 후 NEXT_STEP이 "다음 로그는 P3부터"로 갱신된다.

---

## 6. 새 로그 추가

P2까지 완료된 이후부터는:

```
/root-cause-analyzer
→ "새 로그 분석: C:\logs\ue02_20260626_l1sw.txt"
```

`current_run.yaml`의 `selected_l1sw_txt`를 갱신하고 P3부터 시작한다.

---

## 7. 이어하기

중단 후 재개:

```
/root-cause-analyzer
→ "이어서"
```

`current_run.yaml`의 `next_step`에서 자동 복귀한다.

---

## 8. 사람이 직접 입력하는 것 vs 자동

| 항목 | 자동 | 사람 입력 |
|---|---|---|
| _l1sw.txt 경로 | current_run.yaml에서 자동 사용 | 최초 또는 새 로그 시 지정 |
| issue_type | 카운트 기반 자동 추천 | 직접 지정 가능 |
| 파일명 타임스탬프 | 현재 KST로 자동 | - |
| signal 생성 | prefilter ps1 자동 실행 | - |
| 가설 설정 | P4 7단계 자동 추론 | 원인 직접 알려줄 수 있음 |
| confidence 산정 | 증거 충족도로 자동 | - |
| keyword 승격 | before/after 표 제시 | 확인 후 진행 |
| 각 단계 진행 | current_run.yaml next_step 기반 자동 | `[사람 확인]` 지점에서만 |

---

## 9. 분석 정직성 원칙 (스킬이 지키는 것)

- **미지 모듈 가드**: 원인 줄이 로그에 없으면 confidence를 올리지 않는다.
- **unresolved ≠ low**: 담당영역 밖은 unresolved + handoff. 저신뢰와 혼동하지 않는다.
- **cptime 기준 순서**: wall-clock은 시험마다 다르다. 순서는 항상 cptime.
- **crash/dump 제외**: L1SW Log Analyzer 전담. RCA KG에 crash case 생성 안 함.
- **keyword SSOT**: `keywords.yaml`만 출처. P4에서 키워드를 새로 지어내지 않는다.

---

## 10. 막혔을 때

| 상황 | 보는 파일 |
|---|---|
| 다음에 뭘 해야 하는지 | `NEXT_STEP_5.5.md` |
| 분기 판단 / L1SW 연동 | `RUNBOOK_L1SW_TO_P6_5.5.md` |
| P4 추론이 막힌다 | `prompt/deepdive/RCA_ANALYSIS_METHODOLOGY.md` |
| issue_type 단서 확인 | `skills/root-cause-analyzer/references/seeds/<type>_analyzer.md` |
| 스킬 없이 수동으로 | `prompt/CLAUDE_CODE_PROMPTS_e2e_v1.md` |

---

## 11. 레거시 (스킬 미설치 환경)

`prompt/CLAUDE_CODE_PROMPTS_e2e_v1.md`의 P0 블록부터 순서대로 붙여넣는다.  
공통 운영 규칙은 그 파일 상단에 있다. 동작 결과는 스킬과 동일하다.
