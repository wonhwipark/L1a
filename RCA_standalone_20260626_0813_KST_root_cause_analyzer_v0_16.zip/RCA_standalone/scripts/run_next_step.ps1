param(
  [string]$Root = (Resolve-Path (Join-Path $PSScriptRoot ".."))
)

$ErrorActionPreference = "Stop"
$statePath = Join-Path $Root "rca_kg/runtime_tool_generate/current_run.yaml"
$nextPath = Join-Path $Root "NEXT_STEP_5.5.md"

if (-not (Test-Path $statePath)) {
  Write-Host "current_run.yaml not found. Start with prompt P0."
  exit 1
}

Write-Host "RCA current state: $statePath"
$content = Get-Content $statePath -Raw
$current = ([regex]::Match($content, "(?m)^current_step:\s*(.+)$")).Groups[1].Value.Trim()
$next = ([regex]::Match($content, "(?m)^next_step:\s*(.+)$")).Groups[1].Value.Trim()
$signal = ([regex]::Match($content, "(?m)^\s*signal_file:\s*(.+)$")).Groups[1].Value.Trim()
$case = ([regex]::Match($content, "(?m)^\s*case_file:\s*(.+)$")).Groups[1].Value.Trim()
$l1sw = ([regex]::Match($content, "(?m)^\s*selected_l1sw_txt:\s*(.+)$")).Groups[1].Value.Trim()

Write-Host "current_step: $current"
Write-Host "next_step   : $next"
if ($l1sw -and $l1sw -ne "null") { Write-Host "l1sw_txt    : $l1sw" }
if ($signal -and $signal -ne "null") { Write-Host "signal_file : $signal" }
if ($case -and $case -ne "null") { Write-Host "case_file   : $case" }

Write-Host ""
Write-Host "Open prompt/CLAUDE_CODE_PROMPTS_e2e_v1.md and run block: $next"
Write-Host "Human-readable instruction: $nextPath"
if (Test-Path $nextPath) {
  Write-Host ""
  Get-Content $nextPath -TotalCount 80
}
