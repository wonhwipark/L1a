# 5.5 RCA Knowledge Graph — 전체 사용 시나리오

최종 업데이트: 2026-06-25 01:38 KST  
상태: L1SW-first + stateful convenience v0.14

> 순서대로 따라 할 때는 `START_HERE_5.5.md` → `NEXT_STEP_5.5.md` → `prompt/CLAUDE_CODE_PROMPTS_e2e_v1.md` 순서로 본다.  
> 설계 이력은 `HANDOFF_5.5.md`, 세부 실행 설명은 `RUNBOOK_L1SW_TO_P6_5.5.md`, 수동형 절차는 `scripts/README.md`를 본다.

---

## 0. 전체 흐름

```text
[사내 PC / VSCode + Claude Code / RCA_standalone]

.sdm 원본 로그
  │
  ▼  ① L1SW Log Analyzer: 원본 대용량 로그를 _l1sw.txt로 축소
_l1sw.txt
  │
  ▼  ② P3: issue_type 추천 + signal 생성
rca_kg/signals_tool_generate/*_signal.txt
  │
  ▼  ③ P4: RCA_ANALYSIS_METHODOLOGY 7단계 원인분석
case YAML
  │
  ▼  ④ P5: 자가점검 + 사람 승인
reviewed case
  │
  ▼  ⑤ P6: keywords.yaml candidate → confirmed 승격
누적 Knowledge Graph 성장
```

---

## 1. 이번 버전의 사용자 편의 핵심

| 개선 | 설명 |
|---|---|
| 단일 진입점 | `START_HERE_5.5.md` 추가. 처음 사용자는 이 파일만 보면 됨 |
| 상태 저장 | `rca_kg/runtime_tool_generate/current_run.yaml` 추가. P0~P6가 경로/단계/산출물을 이어받음 |
| 다음 단계 안내 | `NEXT_STEP_5.5.md` 추가. 현재 해야 할 프롬프트와 확인 항목을 사람이 읽음 |
| C0 분기 | P1 전에 `_l1sw.txt`가 없으면 L1SW 실행/선택 절차를 명확히 분리 |
| placeholder 제거 | P2는 최신 `L1SW_OUTPUT_FORMAT_PROBED_*_KST.md`를 자동 검색 |
| 경로 정합성 | signal 출력 경로를 `rca_kg/signals_tool_generate/`으로 통일 |
| 검증 스크립트 | `scripts/validate_package.ps1` 추가 |
| 상태 확인 스크립트 | `scripts/run_next_step.ps1` 추가 |

---

## 2. 운영 모드

### 모드 A — 자율형 권장

```text
START_HERE_5.5.md 확인
  → P0
  → NEXT_STEP_5.5.md 안내에 따라 C0/P1/P2/P3/P4/P5/P6 진행
```

사람은 경로를 반복 입력하지 않는다. Claude Code가 `current_run.yaml`을 읽고 이어간다.

### 모드 B — 수동형

`scripts/README.md`를 따라 PowerShell 명령을 직접 실행한다. 단, 출력 위치는 항상 아래를 사용한다.

```text
rca_kg/signals_tool_generate/
```

---

## 3. 첫 실행 시나리오

| 단계 | 주체 | 행동 | 산출물 |
|---|---|---|---|
| 1 | 사람 | `START_HERE_5.5.md` 확인 | 전체 진입점 파악 |
| 2 | Claude Code | P0 환경 진단 | `current_run.yaml`, P0 review log |
| 3 | 사람/Claude | C0 `_l1sw.txt` 확보 | selected_l1sw_txt 저장 |
| 4 | Claude Code | P1 형식 역설계 | `L1SW_OUTPUT_FORMAT_PROBED_*_KST.md` |
| 5 | Claude Code | P2 fragment 후보 | `manifest_fragments/*.json` |
| 6 | Claude Code | P3 signal 생성 | `signals_tool_generate/*_signal.txt` |
| 7 | Claude Code | P4 원인분석 | `cases/*.yaml` |
| 8 | 사람 | P5 승인 | reviewed case |
| 9 | Claude Code | P6 승격 | `keywords.yaml` 갱신 |

---

## 4. 같은 장애 재발 시나리오

```text
P3 signal 생성
  → P4 fingerprint(signature_set + sequence) 비교
    → 기존 case와 일치
      → 신규 YAML 미생성
      → occurrence_count++ / recent_occurrences 갱신
```

핵심은 wall-clock 시간이 아니라 cptime 기준 상대 sequence와 signature_set이다.

---

## 5. 담당영역 밖 / 원인 미상 시나리오

| 상황 | 저장 위치 | 상태 |
|---|---|---|
| 담당영역 밖 | `cases/unresolved/*_PENDING.yaml` | handoff 대상 |
| 원인 줄이 안 보임, 추가 추출 필요 | case 또는 P4 중단 상태 | confidence low, 추가 추출 안내 |
| 추가 추출 2회 후에도 원인 불명 | `cases/*.yaml` | analyzed + confidence low + 원인 미상 |
| 사람이 직접 원인 규명 | `cases/*.yaml` | 사람 입력 흡수, P5 승인 경로 |

---

## 6. 파일 역할

```text
RCA_standalone/
├─ START_HERE_5.5.md                       ← 최초 진입점
├─ NEXT_STEP_5.5.md                        ← 현재 상태 기준 다음 행동
├─ RUNBOOK_L1SW_TO_P6_5.5.md               ← 실행 순서 설명서
├─ prompt/CLAUDE_CODE_PROMPTS_e2e_v1.md← P0~P6 프롬프트 본문
├─ scripts/validate_package.ps1        ← 패키지 정합성 검사
├─ scripts/run_next_step.ps1           ← current_run 기반 다음 단계 표시
└─ rca_kg/
   ├─ runtime_tool_generate/current_run.yaml ← P0~P6 상태 파일
   ├─ keywords.yaml                     ← signature SSOT
   ├─ signals_tool_generate/                 ← P3 자동 생성 signal
   ├─ indexes_tool_generate/index.md         ← P4/P5 자동 갱신 index
   ├─ manifest_fragments/               ← P2 자동 생성 fragment 후보
   ├─ cases/                            ← case YAML
   └─ schema/                           ← taxonomy/schema
```

---

## 7. 현재 상태

| 레이어 | 상태 |
|---|---|
| L1SW-first 원칙 | 준비됨 |
| P0~P6 프롬프트 | stateful v2로 개정됨 |
| current_run.yaml | 초기 템플릿 포함 |
| NEXT_STEP_5.5.md | P0 시작 상태 포함 |
| START_HERE_5.5.md | 추가됨 |
| taxonomy/skills_seed 정합성 | preamble_collision 및 radio_access_timeout applies_to 정리 |
| E2E 실로그 검증 | 아직 필요 |

다음 한 걸음은 사내 Claude Code에서 P0 실행이다.
