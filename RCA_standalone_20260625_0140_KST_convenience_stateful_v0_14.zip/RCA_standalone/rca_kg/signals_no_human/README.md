# signals_no_human/

> **자동 전용 폴더 (_no_human).** 이 폴더의 파일은 P3(pre-filter)가 생성한다.
> 사람이 직접 만들거나 수정하지 않는다. 손으로 편집하면 분석 입력이 어긋난다.

이 폴더는 pre-filter 스크립트(`scripts/rach_failure_prefilter.ps1` 등) 또는 P3의 출력
(`signal_<issue_type>.txt`)이 저장되는 위치다.

사용법은 `scripts/README.md`의 Step 1을 참고한다.
