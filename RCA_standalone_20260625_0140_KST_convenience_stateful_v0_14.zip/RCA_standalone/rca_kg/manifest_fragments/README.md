# manifest_fragments

이 폴더는 P2가 생성하는 L1SW manifest fragment 후보 JSON의 저장 위치다.

예상 산출물:

```text
rca_kg/manifest_fragments/rca_rach.json
rca_kg/manifest_fragments/rca_scg.json
rca_kg/manifest_fragments/rca_tx.json
rca_kg/manifest_fragments/rca_l2.json
```

이 파일들은 candidate 산출물이다. 사내 L1SW manifest 디렉토리에 반영하기 전 `review_logs/rca_standalone_R4_manifest_fragments_*_KST.md`의 구조 일치 여부를 확인한다.
