# RCA Standalone Package Version

- package_version: convenience_v0.14
- generated_at: 2026-06-25 01:38 KST
- base_package: RCA_standalone_20260625_0120_KST_convenience_nohuman_v0_13.zip
- track: RCA 5.5 standalone
- operating_model: L1SW-first + stateful convenience
- current_status: pre-E2E validation
- primary_input: _l1sw.txt
- raw_log_policy: .sdm is input to L1SW only; RCA P3~P6 uses _l1sw.txt or signal files
- next_step: open START_HERE.md → run P0 → follow NEXT_STEP.md

## v0.14 변경 요약 (2026-06-25 01:38 KST)

사용자 편의 리뷰 개선안을 패키지에 반영했다.

### 신규

- START_HERE.md
- NEXT_STEP.md
- rca_kg/runtime_no_human/current_run.yaml
- rca_kg/runtime_no_human/current_run.example.yaml
- rca_kg/runtime_no_human/README.md
- rca_kg/manifest_fragments/
- scripts/validate_package.ps1
- scripts/run_next_step.ps1

### 수정

- P0~P6 프롬프트를 stateful v2로 개정
- C0 `_l1sw.txt` 확보 분기 추가
- P2 `<YYYYMMDD>` placeholder 제거 및 최신 형식문서 자동 검색
- P3 issue_type 추천/경로 자동을 current_run.yaml과 연결
- P4/P5/P6 case/승인/keywords 승격 흐름을 current_run.yaml로 연결
- RUNBOOK을 A/B/C0/C/D/E/F/G/H/I 구조로 재정리
- scripts/README.md stale signal 경로 수정
- taxonomy에 preamble_collision 추가
- radio_access_timeout applies_to 정합성 확장

## v0.13 이전 주요 이력

- cleanup_v0.13: 사용자 편의 ① issue_type 자동추천 ② 경로 자동 ③ 진행 표시 + 자동전용 폴더 _no_human(signals/indexes)
- cleanup_v0.12: 사람이 원인 규명 시 정보 흡수 경로 추가
- cleanup_v0.11: 미결 종료 선택지 추가
- cleanup_v0.10: 키워드 보강 단계 추가
- cleanup_v0.9: 추가 추출 프로토콜 추가
- cleanup_v0.8: 미지 모듈 가드 추가
- cleanup_v0.7: L1SW-first 정합성 정리
