# START_HERE — RCA Standalone 사용자 시작점

작성일: 2026-06-25 01:38 KST  
대상: 사내 PC, VSCode + Claude Code, `RCA_standalone` 폴더

이 파일은 처음 실행자가 **어느 문서를 먼저 봐야 하는지, 지금 무엇을 해야 하는지**만 안내한다.  
상세 이유와 설계 이력은 `HANDOFF.md`, 전체 설명은 `USAGE_SCENARIO.md`, 단계별 손동작은 `RUNBOOK_L1SW_TO_P6.md`를 본다.

---

## 0. 핵심 원칙

```text
.sdm 원본 로그
  → L1SW Log Analyzer
  → _l1sw.txt
  → RCA P3~P6
  → case YAML / keywords.yaml 성장
```

RCA는 `.sdm` 원본을 직접 분석하지 않는다.  
RCA의 주 입력은 L1SW가 만든 `_l1sw.txt` 또는 P3가 만든 `signals_no_human/*_signal.txt`다.

---

## 1. 처음 열면 이 순서만 따르면 된다

| 순서 | 할 일 | 보는 파일 | 결과 |
|---:|---|---|---|
| 1 | VSCode에서 `RCA_standalone` 폴더 자체를 연다 | - | `@상대경로`가 정상 동작 |
| 2 | 현재 상태를 확인한다 | `NEXT_STEP.md` | 다음 단계 확인 |
| 3 | P0 프롬프트를 Claude Code에 붙여넣는다 | `prompt/CLAUDE_CODE_PROMPTS_e2e_v1.md` | 환경 진단 + `current_run.yaml` 갱신 |
| 4 | `NEXT_STEP.md`가 안내하는 다음 P단계를 실행한다 | `NEXT_STEP.md` | P1/P2/P3... 순차 진행 |
| 5 | 막히면 RUNBOOK의 분기표를 본다 | `RUNBOOK_L1SW_TO_P6.md` | 조치 방향 결정 |

---

## 2. 이 패키지에서 사용자가 직접 편집해도 되는 파일 / 안 되는 파일

### 사용자가 직접 편집해도 되는 파일

```text
rca_kg/keywords.yaml                  # P6 전후 검토/보강 가능. 단, P6 권장.
rca_kg/cases/*.yaml                   # P5 승인/수정 대상
rca_kg/cases/unresolved/*.yaml         # 이관/미결 보강 대상
```

### 사용자가 직접 편집하지 않는 자동 전용 파일

```text
rca_kg/runtime_no_human/current_run.yaml
NEXT_STEP.md
rca_kg/signals_no_human/*
rca_kg/indexes_no_human/index.md
rca_kg/manifest_fragments/*
```

`*_no_human`은 “사람이 전혀 개입하지 않는다”는 뜻이 아니다.  
**사람이 직접 편집하지 않고 Claude Code/스크립트가 갱신하는 폴더**라는 뜻이다. 승인, 원인 판단, 추가 추출 여부 결정은 여전히 사람이 한다.

---

## 3. 현재 패키지의 기본 시작 상태

현재 패키지는 아래 상태 파일을 포함한다.

```text
rca_kg/runtime_no_human/current_run.yaml
```

처음에는 `next_step: P0` 상태다.  
P0가 실행되면 이 파일에 L1SW 경로, `_l1sw.txt` 후보, `.sdm` 후보, 현재 단계가 기록된다. 이후 P1~P6는 이 파일을 읽고 갱신한다.

---

## 4. 최소 실행 루프

```text
P0  환경 진단 + current_run.yaml 생성/갱신
C0  _l1sw.txt 확보. 없으면 L1SW parse.ps1 1회 실행
P1  _l1sw.txt 형식 역설계
P2  L1SW manifest fragment 후보 생성
P3  issue_type 추천 + signal 생성
P4  원인분석 + case YAML 생성/갱신
P5  자가점검 + 사람 승인
P6  keywords.yaml candidate → confirmed 승격
```

각 단계 종료 후 Claude Code는 반드시 아래 두 가지를 갱신해야 한다.

```text
rca_kg/runtime_no_human/current_run.yaml
NEXT_STEP.md
```

---

## 5. 실행 전 자체 검증

패키지 문서/경로 정합성을 점검하려면 PowerShell에서 실행한다.

```powershell
cd "<RCA_standalone_경로>"
.\scriptsalidate_package.ps1
```

검증 대상:

```text
- START_HERE.md 존재 여부
- current_run.yaml / current_run.example.yaml 존재 여부
- NEXT_STEP.md 존재 여부
- active 문서의 옛 signals 경로 잔존 여부
- taxonomy와 skills_seed root_cause category 정합성
- keywords.yaml 기본 구조 존재 여부
```

---

## 6. 문서 역할

| 파일 | 역할 |
|---|---|
| `START_HERE.md` | 처음 보는 사용자의 진입점 |
| `NEXT_STEP.md` | 현재 상태 기준 다음 행동 안내 |
| `RUNBOOK_L1SW_TO_P6.md` | L1SW 연동부터 P6까지 순서와 손동작 |
| `prompt/CLAUDE_CODE_PROMPTS_e2e_v1.md` | Claude Code에 붙여넣는 P0~P6 프롬프트 본문 |
| `USAGE_SCENARIO.md` | 전체 사용 시나리오와 운영 모드 |
| `HANDOFF.md` | 설계 결정 이력과 다음 세션 인계 |
| `scripts/README.md` | 수동형 PowerShell 운영 상세 |
| `prompt/deepdive/RCA_ANALYSIS_METHODOLOGY.md` | P4 원인분석 추론법 |

---

## 7. 첫 번째 명령

Claude Code에 아래 파일의 **P0 블록**을 그대로 붙여넣는다.

```text
prompt/CLAUDE_CODE_PROMPTS_e2e_v1.md
```

그 다음부터는 `NEXT_STEP.md`만 보면 된다.
