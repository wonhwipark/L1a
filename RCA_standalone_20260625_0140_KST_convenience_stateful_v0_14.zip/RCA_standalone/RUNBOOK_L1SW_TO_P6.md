# 5.5 RCA 수행 순서 설명서 — L1SW 연동부터 P0~P6까지

작성일: 2026-06-25 01:38 KST (v3 — 상태 파일 기반 사용자 편의 개정)  
대상: 사내 PC, `RCA_standalone` 폴더를 연 VSCode + Claude Code

이 문서는 실제 실행 순서만 다룬다. 처음 보는 사용자는 `START_HERE.md`를 먼저 본다.

---

## 0. 큰 그림

```text
.sdm 원본 로그
  │
  ▼  L1SW Log Analyzer
_l1sw.txt
  │
  ▼  P3 signal 생성
signals_no_human/*_signal.txt
  │
  ▼  P4/P5/P6
case YAML + keywords.yaml 성장
```

핵심 원칙:

```text
L1SW = 로그 축소
RCA 5.5 = 축소 로그에서 원인분석 + 지식 누적
접점 = _l1sw.txt
```

---

## 1. 사용자 편의 구조

이번 버전부터 아래 두 파일이 실행 상태를 유지한다.

```text
rca_kg/runtime_no_human/current_run.yaml
NEXT_STEP.md
```

- `current_run.yaml`: Claude Code가 읽고 쓰는 machine-readable 상태 파일
- `NEXT_STEP.md`: 사람이 읽는 다음 행동 안내 파일

따라서 세션이 끊겨도 다음에 Claude Code가 `current_run.yaml`을 읽으면 이전 단계 결과를 이어갈 수 있다.

---

## 2. 전체 타임라인

| 구분 | 단계 | 실행 | 한마디로 무슨 동작 | 주요 산출물 | 사람 역할 |
|---|---|---|---|---|---|
| 최초 1회 | A | 수동 | L1SW 스킬 경로 확인 | parse.ps1/manifest 경로 | 경로 확인 |
| 최초 1회 | B | P0 | 환경 진단 + 상태 파일 초기화 | `current_run.yaml`, P0 review log | 표 확인 |
| 최초 1회 | C0 | P0/P1 분기 | `_l1sw.txt` 확보 | selected_l1sw_txt | 필요 시 L1SW 실행 |
| 최초 1회 | C | P1 | `_l1sw.txt` 형식 역설계 | `L1SW_OUTPUT_FORMAT_PROBED_*_KST.md` | cptime 확인 |
| 최초 1회 | D | P2 | manifest fragment 후보 생성 | `manifest_fragments/*.json` | 구조표 확인 |
| 로그마다 | E | 수동 또는 P3 전 | L1SW 실행 | `_l1sw.txt` | 로그 축소 |
| 로그마다 | F | P3 | issue_type 추천 + signal 생성 | `signals_no_human/*_signal.txt` | 추천 확인 |
| 로그마다 | G | P4 | 원인분석 + case 생성/갱신 | `cases/*.yaml` | 인과사슬 확인 |
| 로그마다 | H | P5 | 자가점검 + 승인 | `review.status=reviewed` | `승인` 입력 |
| 로그마다 | I | P6 | keywords 승격 | `keywords.yaml` 갱신 | before/after 확인 |

---

# 최초 1회 — 환경 셋업

## STEP A — L1SW 스킬 연동 확인

PowerShell에서 L1SW가 있는지 확인한다.

```powershell
Test-Path "C:\Users\whpark\.claude\skills\l1sw-log-analyzer\scripts\parse.ps1"
Get-ChildItem "C:\Users\whpark\.claude\skills\l1sw-log-analyzer\manifest\"
```

경로가 다르면 실제 경로를 P0에서 자동 탐색하거나, P0 결과가 실패할 때 알려준다.

---

## STEP B — P0 환경 자가 진단

`prompt/CLAUDE_CODE_PROMPTS_e2e_v1.md`의 P0 블록을 Claude Code에 붙여넣는다.

P0가 하는 일:

```text
- RCA_standalone 루트 확인
- .sdm / _l1sw.txt 후보 검색
- L1SW parse.ps1 / manifest 검색
- PowerShell prefilter 구조 확인
- cases/signals/indexes 상태 확인
- current_run.yaml 갱신
- NEXT_STEP.md 갱신
- review_logs/p0_env_probe_* 생성
```

P0 후 판단:

| 결과 | 다음 |
|---|---|
| `_l1sw.txt` 1개 선택됨 | P1 |
| `_l1sw.txt` 여러 개 | C0에서 번호 선택 |
| `_l1sw.txt` 없음, `.sdm` 있음 | C0에서 L1SW 실행 |
| L1SW 못 찾음 | L1SW 경로 제공 후 P0 재실행 |

---

## STEP C0 — `_l1sw.txt` 확보

P1은 실제 `_l1sw.txt`가 있어야 한다. 없으면 C0를 먼저 처리한다.

### 경우 1. `_l1sw.txt`가 이미 있다

P0가 `current_run.yaml`에 자동 저장한다.

```yaml
input:
  selected_l1sw_txt: D:/logs/dump001_l1sw.txt
```

바로 P1로 간다.

### 경우 2. `_l1sw.txt` 후보가 여러 개다

Claude Code가 번호 목록을 보여준다.

```text
1) D:/logs/a_l1sw.txt
2) D:/logs/b_l1sw.txt
```

사람은 번호만 입력한다.

### 경우 3. `.sdm`만 있다

L1SW 실행이 필요하다. P0/P1이 실제 `parse.ps1` 경로를 기준으로 명령을 안내한다.

```powershell
cd "C:\Users\whpark\.claude\skills\l1sw-log-analyzer\scripts"
.\parse.ps1 <환경에서 확인된 실제 파라미터> "D:\logs\dump001.sdm"
```

생성된 `_l1sw.txt` 경로를 `current_run.yaml`에 저장한 뒤 P1로 간다.

---

## STEP C — P1 `_l1sw.txt` 형식 역설계

P1이 하는 일:

```text
- selected_l1sw_txt 읽기
- 앞부분/무작위 구간 샘플링
- cptime 포맷 확인
- module/component 위치 확인
- prompt/deepdive/L1SW_OUTPUT_FORMAT_PROBED_<YYYYMMDD>_<HHMM>_KST.md 생성
- current_run.yaml p1 갱신
- NEXT_STEP.md를 P2로 갱신
```

사람은 cptime 포맷만 1회 눈으로 확인한다.

---

## STEP D — P2 manifest fragment 후보 생성

P2는 P1 산출물을 자동으로 찾는다. 사용자가 `<YYYYMMDD>`를 직접 바꾸지 않는다.

입력 우선순위:

```text
1. current_run.yaml의 p1.output_format_doc
2. prompt/deepdive/L1SW_OUTPUT_FORMAT_PROBED_*_KST.md 중 최신 파일
3. 여러 개면 번호 선택
```

출력:

```text
rca_kg/manifest_fragments/rca_rach.json
rca_kg/manifest_fragments/rca_scg.json
rca_kg/manifest_fragments/rca_tx.json
rca_kg/manifest_fragments/rca_l2.json
review_logs/rca_standalone_R4_manifest_fragments_*_KST.md
```

사람은 L1SW 기존 fragment 구조와 일치하는지 표만 확인한다.

---

# 로그마다 반복

## STEP E — L1SW 실행

새 `.sdm` 로그마다 먼저 L1SW를 실행해 `_l1sw.txt`를 만든다.

```powershell
cd "C:\Users\whpark\.claude\skills\l1sw-log-analyzer\scripts"
.\parse.ps1 <P0/P1이 확인한 실제 파라미터> "D:\logs\dump001.sdm"
```

생성된 `_l1sw.txt`가 있으면 P3로 간다. P3에서 경로를 비워도 `current_run.yaml` 또는 최신 파일을 자동 사용한다.

---

## STEP F — P3 issue_type 추천 + signal 생성

P3가 하는 일:

```text
- selected_l1sw_txt 자동 사용
- issue_type 비어 있으면 4유형 hit 수 비교
- 가장 가능성 높은 issue_type 추천
- 확정 후 signals_no_human/*_signal.txt 생성
- signal 줄 수 / signature hit / module 목록 / cptime 범위 보고
- current_run.yaml p3 갱신
- NEXT_STEP.md를 P4로 갱신
```

사람은 추천 issue_type과 signal 줄 수만 확인한다.

---

## STEP G — P4 원인분석 + case 생성/갱신

P4는 `RCA_ANALYSIS_METHODOLOGY.md`의 7단계 추론을 따른다.

중요 가드:

```text
- 증상을 원인으로 쓰지 않는다.
- 보이는 로그만으로 억지 원인을 만들지 않는다.
- 원인 줄이 필터 밖에 있으면 미지 모듈 가드를 적용한다.
- 추가 추출은 최대 2회까지만 기록한다.
```

출력:

```text
rca_kg/cases/<fingerprint-slug>_<issue_type>_<seq>.yaml
또는
rca_kg/cases/unresolved/<YYYYMMDD>_<issue_type>_<seq>_PENDING.yaml
```

사람은 인과사슬 1줄과 confidence만 본다.

---

## STEP H — P5 자가점검 + 승인

P5는 schema/taxonomy/keywords 정합성을 검사한다.

검사 핵심:

```text
- root_cause.category가 issue_type에 적용 가능한가
- signature ID가 keywords.yaml에 있는가
- fingerprint에 generic signature가 들어가지 않았는가
- confidence가 과하지 않은가
- line_range/raw_examples/related.jira 금지 규칙을 어기지 않았는가
```

문제가 없으면 사람은 아래 한 단어만 입력한다.

```text
승인
```

승인 후:

```text
review.status: reviewed
fingerprint.sequence_status: confirmed
current_run.yaml p5.approved: true
NEXT_STEP.md → P6
```

---

## STEP I — P6 keywords 승격

P6는 승인된 case의 근거 signature만 `candidate → confirmed`로 승격한다.

출력:

```text
keywords.yaml 갱신
review_logs/rca_standalone_P6_keywords_promotion_*_KST.md
NEXT_STEP.md → 완료 / 다음 로그는 P3부터
```

사람은 before/after 표에서 과한 승격이 없는지만 확인한다.

---

# 막힘 분기표

| 증상 | 가능 원인 | 조치 |
|---|---|---|
| P0가 L1SW를 못 찾음 | 경로가 기본값과 다름 | 실제 parse.ps1 경로를 알려주고 P0 재실행 |
| P1에서 `_l1sw.txt` 없음 | L1SW 미실행 | C0에서 L1SW 1회 실행 |
| P2가 P1 산출물을 못 찾음 | 형식 문서 없음/경로 불일치 | 최신 `L1SW_OUTPUT_FORMAT_PROBED_*_KST.md` 선택 |
| P3 signal 0줄 | 키워드 미매칭 또는 issue_type 오판 | issue_type 추천표 확인, Context 확대, 키워드 후보 점검 |
| P4에서 원인 줄이 비어 있음 | 미지 모듈/필터 누락 | 추가 추출 프로토콜. 최대 2회 |
| P4가 담당영역 밖으로 판단 | RF/PHY/외부도메인 가능 | unresolved PENDING 생성 |
| P5 taxonomy 오류 | skills_seed와 taxonomy 불일치 | taxonomy 또는 skills_seed 정합성 수정 |
| P6 승격 대상이 과함 | generic/candidate 과다 포함 | 승인된 근거 signature만 승격 |

---

# 검증

패키지 자체 정합성은 아래로 점검한다.

```powershell
cd "<RCA_standalone_경로>"
.\scripts\validate_package.ps1
```
