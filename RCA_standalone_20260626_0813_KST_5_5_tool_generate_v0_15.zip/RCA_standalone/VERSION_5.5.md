# RCA Standalone Package Version

- package_version: convenience_v0.15
- generated_at: 2026-06-26 08:13 KST
- base_package: RCA_standalone_20260625_0140_KST_convenience_stateful_v0_14.zip
- track: RCA 5.5 standalone
- operating_model: L1SW-first + stateful convenience
- current_status: pre-E2E validation
- primary_input: _l1sw.txt
- raw_log_policy: .sdm is input to L1SW only; RCA P3~P6 uses _l1sw.txt or signal files
- next_step: open START_HERE_5.5.md → run P0 → follow NEXT_STEP_5.5.md

## v0.15 변경 요약 (2026-06-26 08:13 KST)

5.2 CodeAnalyzer 패키지와 동일 컨셉의 편의 점검을 적용하고, 5.2와 충돌하지 않도록 정리했다.

### 1. _5.5 접미사 (5.2와 충돌 방지)

최상위 네비게이션 문서명을 5.2 패키지의 `_5.2` 규칙과 동일하게 `_5.5`로 붙였다. 두 패키지를 한 작업공간에 둬도 "START_HERE"가 모호하지 않다.

```text
START_HERE.md          → START_HERE_5.5.md
NEXT_STEP.md           → NEXT_STEP_5.5.md
HANDOFF.md             → HANDOFF_5.5.md
VERSION.md             → VERSION_5.5.md
USAGE_SCENARIO.md      → USAGE_SCENARIO_5.5.md
RUNBOOK_L1SW_TO_P6.md  → RUNBOOK_L1SW_TO_P6_5.5.md
```

rca_kg/ · prompt/ · scripts/ 내부 파일은 폴더로 이미 네임스페이스가 분리되어 그대로 둔다. 모든 문서·스크립트의 상호 참조 경로는 일괄 갱신했다.

### 2. no_human → tool_generate 리네이밍

"사람이 안 한다"보다 "도구가 생성한다"가 의미에 더 맞으므로 변경했다.

```text
rca_kg/runtime_no_human/  → rca_kg/runtime_tool_generate/
rca_kg/signals_no_human/  → rca_kg/signals_tool_generate/
rca_kg/indexes_no_human/  → rca_kg/indexes_tool_generate/
인라인 표기 _no_human      → _tool_generate
```

폴더 의미 설명도 "도구가 쓰고, 사람이 판단한다"로 다듬었다. 모든 path 참조(md/ps1/yaml) 일괄 갱신.

### 3. 편의 점검 (5.2 v0.4와 동일 컨셉)

```text
1. START_HERE 상단에 "평소엔 이 파일 하나면 된다" 문서 지도 추가.
2. 진행 줄 다음에 "▶ 다음 붙여넣기: ... 의 <P단계> 블록" 한 줄 안내 추가.
   → 사용자가 다음 어느 블록을 붙여넣을지 스스로 판단하지 않게 함.
3. 파일명 타임스탬프 <YYYYMMDD>_<HHMM>은 사람이 적지 않고 도구가 현재 KST로 채움을 명문화.
```

### 4. 깨진 제어문자 수정 (동작 버그)

START_HERE 자체 검증 명령에 VT(0x0B) 제어문자가 섞여 `.\scripts\validate_package.ps1`의 `v`가 사라져 있었다. 그대로 복사하면 실행 실패. 수정했다. 패키지 전체에 제어문자 0개 확인.

## v0.14 변경 요약 (2026-06-25 01:38 KST)

사용자 편의 리뷰 개선안을 패키지에 반영했다.

### 신규

- START_HERE_5.5.md
- NEXT_STEP_5.5.md
- rca_kg/runtime_tool_generate/current_run.yaml
- rca_kg/runtime_tool_generate/current_run.example.yaml
- rca_kg/runtime_tool_generate/README.md
- rca_kg/manifest_fragments/
- scripts/validate_package.ps1
- scripts/run_next_step.ps1

### 수정

- P0~P6 프롬프트를 stateful v2로 개정
- C0 `_l1sw.txt` 확보 분기 추가
- P2 `<YYYYMMDD>` placeholder 제거 및 최신 형식문서 자동 검색
- P3 issue_type 추천/경로 자동을 current_run.yaml과 연결
- P4/P5/P6 case/승인/keywords 승격 흐름을 current_run.yaml로 연결
- RUNBOOK을 A/B/C0/C/D/E/F/G/H/I 구조로 재정리
- scripts/README.md stale signal 경로 수정
- taxonomy에 preamble_collision 추가
- radio_access_timeout applies_to 정합성 확장

## v0.13 이전 주요 이력

- cleanup_v0.13: 사용자 편의 ① issue_type 자동추천 ② 경로 자동 ③ 진행 표시 + 자동전용 폴더 _tool_generate(signals/indexes)
- cleanup_v0.12: 사람이 원인 규명 시 정보 흡수 경로 추가
- cleanup_v0.11: 미결 종료 선택지 추가
- cleanup_v0.10: 키워드 보강 단계 추가
- cleanup_v0.9: 추가 추출 프로토콜 추가
- cleanup_v0.8: 미지 모듈 가드 추가
- cleanup_v0.7: L1SW-first 정합성 정리
