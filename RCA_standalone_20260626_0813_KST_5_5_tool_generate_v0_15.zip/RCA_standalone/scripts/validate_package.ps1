param(
  [string]$Root = (Resolve-Path (Join-Path $PSScriptRoot ".."))
)

$ErrorActionPreference = "Stop"
$failed = $false

function Pass($msg) { Write-Host "[OK]   $msg" }
function Warn($msg) { Write-Host "[WARN] $msg"; $script:failed = $true }
function Info($msg) { Write-Host "[INFO] $msg" }

Info "RCA package validation root: $Root"

$required = @(
  "START_HERE_5.5.md",
  "NEXT_STEP_5.5.md",
  "prompt/CLAUDE_CODE_PROMPTS_e2e_v1.md",
  "RUNBOOK_L1SW_TO_P6_5.5.md",
  "rca_kg/runtime_tool_generate/current_run.yaml",
  "rca_kg/runtime_tool_generate/current_run.example.yaml",
  "rca_kg/signals_tool_generate/README.md",
  "rca_kg/indexes_tool_generate/index.md",
  "rca_kg/schema/taxonomy.yaml",
  "rca_kg/keywords.yaml"
)

foreach ($rel in $required) {
  $path = Join-Path $Root $rel
  if (Test-Path $path) { Pass "exists: $rel" } else { Warn "missing: $rel" }
}

# Active docs should not use the old signal path. Historical delta/review_logs are intentionally skipped.
$activeFiles = Get-ChildItem $Root -Recurse -File -Include *.md,*.ps1,*.yaml,*.yml,*.json |
  Where-Object { $_.FullName -notmatch "[\\/]delta[\\/]" -and $_.FullName -notmatch "[\\/]review_logs[\\/]" }

$oldPathHits = @()
$oldForward = "rca_kg" + "/" + "signals" + "/"
$oldBack = "rca_kg" + "\\" + "signals" + "\\"
foreach ($f in $activeFiles) {
  if ($f.Name -eq "validate_package.ps1") { continue }
  $content = Get-Content $f.FullName -Raw -ErrorAction SilentlyContinue
  if ($content.Contains($oldForward) -or $content.Contains($oldBack)) {
    $oldPathHits += $f.FullName
  }
}
if ($oldPathHits.Count -eq 0) { Pass "no stale signal folder path in active docs" }
else { Warn "stale signal folder path found:`n$($oldPathHits -join "`n")" }

# Check taxonomy categories referenced by active skills_seed. crash_analyzer.md is skipped because crash/dump is L1SW-owned external scope.
$taxonomyPath = Join-Path $Root "rca_kg/schema/taxonomy.yaml"
$taxonomy = Get-Content $taxonomyPath -Raw
$categoryNames = @{}
foreach ($m in [regex]::Matches($taxonomy, "(?m)^  ([a-z0-9_]+):\r?$")) {
  $categoryNames[$m.Groups[1].Value] = $true
}

$seedFiles = Get-ChildItem (Join-Path $Root "rca_kg/skills_seed") -Filter "*_analyzer.md" | Where-Object { $_.Name -ne "crash_analyzer.md" }
$missingCats = @()
foreach ($sf in $seedFiles) {
  $lines = Get-Content $sf.FullName
  foreach ($line in $lines) {
    if ($line -match "^\|\s*([a-z0-9_]+)\s*\|") {
      $cat = $Matches[1]
      if ($cat -ne "category" -and -not $categoryNames.ContainsKey($cat)) {
        $missingCats += "$($sf.Name): $cat"
      }
    }
  }
}
if ($missingCats.Count -eq 0) { Pass "skills_seed categories exist in taxonomy" }
else { Warn "skills_seed categories missing in taxonomy:`n$($missingCats -join "`n")" }

# Basic keywords.yaml structure check.
$keywordsPath = Join-Path $Root "rca_kg/keywords.yaml"
$keywords = Get-Content $keywordsPath -Raw
foreach ($issue in @("rach_failure", "scg_failure", "tx_abnormal", "l2_max_retransmission")) {
  if ($keywords -match $issue) { Pass "keywords contains issue_type: $issue" }
  else { Warn "keywords missing issue_type text: $issue" }
}

if ($failed) {
  Write-Host "`n[RESULT] validation completed with warnings/failures. Review items above."
  exit 1
} else {
  Write-Host "`n[RESULT] validation passed."
  exit 0
}
