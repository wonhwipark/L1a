# RCA Standalone — 새 사용자 빠른 시작

버전: convenience_v0.19 manifest guard 릴리스  
갱신: 2026-06-27 10:38 KST  
스킬: `root-cause-analyzer` (`/root-cause-analyzer`)

이 패키지는 L1SW Log Analyzer가 만든 `_l1sw.txt`를 입력으로 받아 L1 장애의 근본 원인 분석(RCA), case YAML 생성, keywords.yaml 후보 승격을 수행하는 Claude Code 스킬 패키지다.

---

## 1. 처음이면 이 순서만 따른다

```powershell
# 1) ZIP 압축 해제 후 이 폴더로 이동
cd .\RCA_standalone

# 2) 스킬 설치
.\install_skill.ps1

# 3) 설치 확인
.\validate_install.ps1
```

설치 후 Claude Code 또는 VSCode를 재시작한다.

Claude Code에서 호출한다.

```text
/root-cause-analyzer
```

`_l1sw.txt`가 있으면 다음처럼 요청한다.

```text
C:\logs\ue01_l1sw.txt 원인 분석해줘
```

`.sdm`만 있으면 먼저 L1SW Log Analyzer로 `_l1sw.txt`를 만들어야 한다. RCA는 `.sdm` 원본을 직접 분석하지 않는다.

---

## 2. 문서 역할

| 문서 | 언제 보는가 |
|---|---|
| `README.md` | ZIP을 처음 받은 사람이 가장 먼저 본다. |
| `START_HERE_5.5.md` | 정상 사용 흐름을 짧게 확인한다. |
| `INSTALL_SKILL.md` | 설치 옵션, 경로 직접 지정, 재설치를 확인한다. |
| `USER_GUIDE_5.5.md` | 설치 후 P0~P6 사용법을 확인한다. |
| `NEXT_STEP_5.5.md` | 현재 상태와 다음 한 걸음을 확인한다. |
| `RUNBOOK_L1SW_TO_P6_5.5.md` | 실행 중 막혔을 때 증상별 조치를 확인한다. |
| `USAGE_SCENARIO_5.5.md` | 전체 운영 시나리오를 이해한다. |
| `VERSION_5.5.md` | 변경 이력을 확인한다. |
| `HANDOFF_5.5.md` | 설계 이력/유지보수용이다. 일반 사용자는 보통 보지 않는다. |

`prompt/` 폴더는 스킬 설치가 불가능한 환경의 레거시 수동 모드다. 정상 사용자는 열지 않는다.

---

## 3. 결과물 위치

대표 결과물:

```text
rca_kg/runtime_tool_generate/current_run.yaml
rca_kg/signals_tool_generate/*_signal.txt
rca_kg/cases/*.yaml
rca_kg/cases/unresolved/*.yaml
rca_kg/indexes_tool_generate/index.md
rca_kg/keywords.yaml
```
