# scripts/README — RCA 보조 스크립트 안내

갱신: 2026-06-27 10:38 KST  
상태: 보조/수동 도구 설명서

정상 사용자는 이 문서를 먼저 보지 않는다. 정상 흐름은 아래 문서와 스킬 호출을 따른다.

```text
README.md → START_HERE_5.5.md → /root-cause-analyzer
```

이 폴더의 PowerShell 스크립트는 RCA 스킬이 실행 중 필요할 때 호출하거나, 스킬 설치가 불가능한 환경에서 수동으로 signal을 만들 때만 사용한다.

---

## 1. 스크립트 목록

| 파일 | 역할 | 일반 사용자 직접 실행 |
|---|---|---|
| `validate_package.ps1` | 패키지 구조 정합성 검사 | 선택 |
| `run_next_step.ps1` | `current_run.yaml` 기준 다음 단계 표시 | 선택 |
| `rach_failure_prefilter.ps1` | RACH failure signal 후보 생성 | 보통 불필요 |
| `scg_failure_prefilter.ps1` | SCG failure signal 후보 생성 | 보통 불필요 |

---

## 2. 정상 사용자 권장 흐름

```powershell
# 패키지 루트에서
.\install_skill.ps1
.\validate_install.ps1
```

그 다음 Claude Code에서 실행한다.

```text
/root-cause-analyzer
C:\logs\ue01_l1sw.txt 원인 분석해줘
```

---

## 3. 패키지 구조 검증

배포 ZIP이 깨졌는지 확인하고 싶을 때 실행한다.

```powershell
.\scripts\validate_package.ps1
```

---

## 4. 현재 다음 단계 확인

```powershell
.\scripts\run_next_step.ps1
```

기준 파일:

```text
rca_kg/runtime_tool_generate/current_run.yaml
NEXT_STEP_5.5.md
```

---

## 5. signal prefilter 수동 실행

스킬이 자동으로 처리하는 것이 기본이다. 수동 실행은 디버깅 또는 레거시 환경에서만 사용한다.

예시:

```powershell
.\scripts\rach_failure_prefilter.ps1 -InputPath "C:\logs\ue01_l1sw.txt" -OutputPath ".\rca_kg\signals_tool_generate\ue01_rach_signal.txt"
```

출력 위치는 반드시 아래를 사용한다.

```text
rca_kg/signals_tool_generate/
```

---

## 6. 주의

```text
- RCA의 주 입력은 _l1sw.txt다.
- .sdm 원본은 L1SW Log Analyzer에서 먼저 처리한다.
- scripts/는 정상 시작 문서가 아니다.
- prompt/ 폴더는 legacy only다.
```
