# START_HERE_5.5 — RCA 정상 사용 시작점

마지막 갱신: 2026-06-27 10:38 KST  
대상 버전: convenience_v0.19  
권장 방식: `/root-cause-analyzer` 스킬 사용

이 문서는 처음/평소 사용자가 보는 짧은 시작 안내다. 설치 상세는 `INSTALL_SKILL.md`, 실제 사용 예시는 `USER_GUIDE_5.5.md`, 문제 해결은 `RUNBOOK_L1SW_TO_P6_5.5.md`를 본다.

---

## 1. 한 줄 요약

```text
ZIP 해제 → .\install_skill.ps1 → VSCode/Claude Code 재시작 → _l1sw.txt 준비 → /root-cause-analyzer → 로그 경로 입력
```

---

## 2. 입력 파이프라인

```text
.sdm 원본
  → L1SW Log Analyzer
  → _l1sw.txt
  → /root-cause-analyzer
  → P0~P6 RCA
  → case YAML / keywords.yaml 후보
```

중요:

```text
- RCA는 .sdm 원본을 직접 분석하지 않는다.
- RCA의 주 입력은 _l1sw.txt 또는 signal 파일이다.
- _l1sw.txt가 없으면 P0/C0에서 L1SW 실행 또는 준비 방법을 안내한다.
```

---

## 3. 최초 1회 설치

패키지 루트에서 실행한다.

```powershell
.\install_skill.ps1
.\validate_install.ps1
```

다른 위치에 설치해야 하면 `INSTALL_SKILL.md`의 `-TargetSkillsDir` 옵션을 사용한다.

---

## 4. 분석 시작

Claude Code에서 호출한다.

```text
/root-cause-analyzer
```

요청 예시:

```text
C:\logs\ue01_20260627_l1sw.txt 원인 분석해줘
```

스킬이 자동으로 처리하는 항목:

```text
- P0 환경 진단
- _l1sw.txt 유무 확인
- current_run.yaml 갱신
- P1 로그 포맷 역설계
- P2 manifest fragment 후보 생성
- P3 issue_type 추천
- P4 원인분석과 case YAML 생성/갱신
- P5 자가점검/승인 정규화
- P6 keywords 후보 승격
```

---

## 5. 이어하기

진행 중 세션이 끊기면 다시 호출한다.

```text
/root-cause-analyzer
이어서 진행해줘
```

스킬은 아래 상태를 기준으로 복귀한다.

```text
rca_kg/runtime_tool_generate/current_run.yaml
NEXT_STEP_5.5.md
```

---

## 6. 문서 지도

| 목적 | 문서 |
|---|---|
| 처음 시작 | `README.md`, `START_HERE_5.5.md` |
| 설치 상세 | `INSTALL_SKILL.md` |
| 사용 예시 | `USER_GUIDE_5.5.md` |
| 현재 다음 단계 | `NEXT_STEP_5.5.md` |
| 문제 해결 | `RUNBOOK_L1SW_TO_P6_5.5.md` |
| 전체 운영 시나리오 | `USAGE_SCENARIO_5.5.md` |
| 설계/유지보수 | `HANDOFF_5.5.md`, `VERSION_5.5.md` |

---

## 7. 레거시 수동 모드

`prompt/` 폴더의 P0~P6 프롬프트는 스킬 설치가 불가능한 환경에서만 사용한다. 정상 흐름에서는 사용하지 않는다.
