# NEXT_STEP_5.5 — RCA 다음 행동

마지막 갱신: 2026-06-27 10:38 KST  
상태 파일: `rca_kg/runtime_tool_generate/current_run.yaml` + `NEXT_STEP_5.5.md`

---

## 1. 현재 상태

```text
package_version: convenience_v0.18
current_step: INIT
next_step: INSTALL_OR_RUN_SKILL
primary_input: _l1sw.txt
progress_cursor: [진행: INIT → 다음: INSTALL_OR_RUN_SKILL]
```

---

## 2. 다음 한 걸음

### 스킬 미설치

```powershell
.\install_skill.ps1
.\validate_install.ps1
```

설치 후 Claude Code 또는 VSCode를 재시작한다.

### 스킬 설치 완료 + _l1sw.txt 있음

```text
/root-cause-analyzer
C:\logs\ue01_l1sw.txt 원인 분석해줘
```

### 스킬 설치 완료 + .sdm만 있음

```text
/root-cause-analyzer
.sdm만 있고 _l1sw.txt는 아직 없어. 다음 단계 안내해줘
```

### 진행 중 이어하기

```text
/root-cause-analyzer
이어서 진행해줘
```

---

## 3. 완료 후 기대 결과

```text
rca_kg/runtime_tool_generate/current_run.yaml 갱신
rca_kg/signals_tool_generate/*_signal.txt 생성
rca_kg/cases/*.yaml 생성 또는 갱신
rca_kg/indexes_tool_generate/index.md 갱신
rca_kg/keywords.yaml candidate/confirmed 갱신 후보 생성
```

---

## 4. 막히면

`RUNBOOK_L1SW_TO_P6_5.5.md`를 본다.
