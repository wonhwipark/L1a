# USER_GUIDE_5.5 — root-cause-analyzer 사용 가이드

버전: convenience_v0.18  
갱신: 2026-06-27 10:38 KST  
대상: L1SW 로그 기반 RCA, case YAML 생성, keywords 후보 승격

---

## 1. 입력 파이프라인

```text
.sdm 원본
  → L1SW Log Analyzer
  → _l1sw.txt
  → /root-cause-analyzer
  → P0~P6
  → case YAML / keywords.yaml 후보
```

RCA는 `.sdm`을 직접 읽지 않는다. `_l1sw.txt`가 없으면 P0/C0에서 L1SW 실행 또는 파일 준비를 안내한다.

---

## 2. 설치 확인

설치가 아직이면 먼저 `INSTALL_SKILL.md`를 따른다.

```powershell
.\install_skill.ps1
.\validate_install.ps1
```

설치 후 Claude Code 또는 VSCode를 재시작한다.

---

## 3. 처음 분석 시작

Claude Code에서 호출한다.

```text
/root-cause-analyzer
```

요청 예시:

```text
C:\logs\ue01_20260627_l1sw.txt 원인 분석해줘
```

스킬은 `current_run.yaml`과 `NEXT_STEP_5.5.md`를 기준으로 P0부터 시작하거나 진행 중 단계로 복귀한다.

---

## 4. 단계 개요

| 단계 | 목적 | 사람 확인 |
|---|---|---|
| P0 | 환경 진단, `_l1sw.txt` 유무 확인, 상태 초기화 | 필요 |
| C0 | `_l1sw.txt` 확보 안내 | 필요 시 |
| P1 | `_l1sw.txt` 포맷 역설계 | 필요 |
| P2 | manifest fragment 후보 생성 | 필요 |
| P3 | issue_type 추천, signal 생성 | 필요 |
| P4 | 원인분석 7단계, case YAML 생성/갱신 | 필요 |
| P5 | 자가점검, 승인 정규화 | 필요 |
| P6 | keywords candidate 승격 | 필요 |

두 번째 로그부터는 상태가 준비되어 있으면 보통 P3부터 시작한다.

---

## 5. issue_type

현재 기본 대상:

```text
rach_failure
scg_failure
tx_abnormal
l2_max_retransmission
```

P3에서 대표 signature 등장 횟수를 기반으로 추천한다. 사용자가 직접 지정할 수도 있다.

```text
이 로그는 scg_failure 기준으로 분석해줘
```

---

## 6. 이어하기

세션이 끊겼거나 멈췄으면 다시 호출한다.

```text
/root-cause-analyzer
이어서 진행해줘
```

기준 상태 파일:

```text
rca_kg/runtime_tool_generate/current_run.yaml
NEXT_STEP_5.5.md
```

---

## 7. 결과 확인

| 파일/폴더 | 의미 |
|---|---|
| `current_run.yaml` | 현재 RCA 진행 상태 |
| `signals_tool_generate/` | P3에서 생성한 issue_type별 signal |
| `cases/*.yaml` | 분석 완료 또는 승인 대기 case |
| `cases/unresolved/*.yaml` | 담당영역 밖/원인 미상/추가 확인 필요 case |
| `indexes_tool_generate/index.md` | case 검색용 index |
| `keywords.yaml` | confirmed/candidate signature 지식 |

---

## 8. 분석 정직성 원칙

```text
- 모르는 모듈을 아는 것처럼 단정하지 않는다.
- anchor cptime과 최초 이탈 지점을 분리한다.
- 가설은 최소 2개 이상 비교한다.
- evidence가 약하면 confidence를 낮게 기록한다.
- L1 담당영역 밖이면 unresolved로 분리한다.
```

---

## 9. 막혔을 때

증상별 조치는 `RUNBOOK_L1SW_TO_P6_5.5.md`를 본다.

대표 조치:

```text
- 설치 문제: INSTALL_SKILL.md
- 현재 다음 단계 불명확: NEXT_STEP_5.5.md
- _l1sw.txt 없음: RUNBOOK의 C0 분기
- issue_type 불명확: P3 추천 또는 직접 지정
- 원인 미상: unresolved case로 저장
```

---

## 10. 레거시 수동 모드

`prompt/` 폴더는 스킬 설치가 불가능한 환경의 하위 호환용이다. 새 사용자는 기본적으로 사용하지 않는다.
