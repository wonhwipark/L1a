# runtime_tool_generate

갱신: 2026-06-27 10:38 KST

이 폴더는 RCA 실행 상태를 저장하는 도구 생성 영역이다. 일반 사용자는 직접 편집하지 않고 `NEXT_STEP_5.5.md` 또는 `/root-cause-analyzer`의 안내를 따른다.

## 파일

| 파일 | 역할 |
|---|---|
| `current_run.yaml` | 현재 실행 상태. P0~P6가 읽고 갱신한다. |
| `current_run.example.yaml` | 상태 파일 예시. 손상 시 복구 참고용. |

## 운영 규칙

1. P0는 `current_run.yaml`을 생성/초기화한다.
2. P1~P6는 이전 단계의 결과를 이 파일에서 읽는다.
3. 각 단계 종료 시 `current_step`, `next_step`, `last_updated_kst`를 갱신한다.
4. 사용자는 이 파일을 직접 편집하지 않고 `NEXT_STEP_5.5.md`를 본다.
5. 세션이 바뀌어도 Claude Code는 이 파일을 읽고 이어서 진행한다.
